'use strict';

const STORAGE_KEY = 'sepas.store.v1';
const MAX_PRICE = 999_999_999;
const MAX_STOCK = 100_000;
const MAX_TOTAL = 999_999_999_999;
const lowStock = 3;
const payments = ['کارت‌خوان', 'نقدی', 'انتقال بانکی'];
const formatter = new Intl.NumberFormat('fa-IR');
const dateFormatter = new Intl.DateTimeFormat('fa-IR', { day: 'numeric', month: 'long', year: 'numeric' });
const timeFormatter = new Intl.DateTimeFormat('fa-IR', { hour: '2-digit', minute: '2-digit' });
const page = document.querySelector('#page');
const dialog = document.querySelector('#dialog');
const navigation = document.querySelector('#navigation');
const backupFile = document.querySelector('#backup-file');
const notification = document.querySelector('#notification');

const drawings = {
  register: '<path d="M5 3h14M7 3v6m10-6v6M4 9h16l2 5v6H2v-6zM2 15h20M10 18h4"/>',
  settings: '<path d="M4 6h16M4 12h16M4 18h16M8 4v4m8 2v4m-5 2v4"/>',
  home: '<path d="M3 10l9-7 9 7v10H3zM9 20v-6h6v6"/>',
  box: '<path d="M3 7l9-4 9 4v10l-9 4-9-4zM3 7l9 4 9-4m-9 4v10M8 5l9 4"/>',
  receipt: '<path d="M5 3h14v18l-3-2-4 2-4-2-3 2zM9 8h6m-6 4h6m-6 4h3"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  minus: '<path d="M5 12h14"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  alert: '<path d="M12 3l10 17H2zM12 10v4m0 3v.1"/>',
  search: '<circle cx="10.5" cy="10.5" r="6"/><path d="M15 15l5 5"/>',
  cross: '<path d="M6 6l12 12M18 6L6 18"/>',
  report: '<path d="M4 4v16h16M8 15v2m4-6v6m4-10v10"/>',
  download: '<path d="M12 3v12m-4-4l4 4 4-4M4 17v4h16v-4"/>'
};

const routes = [
  ['home', 'خانه', 'home'], ['stock', 'کالاها', 'box'], ['cash', 'صندوق', 'register'],
  ['history', 'فروش‌ها', 'receipt'], ['report', 'گزارش', 'report']
];
const queries = { stock: '', cash: '', history: '' };
let current = 'home';
let cart = new Map();
let notificationTimer;
let loadError = false;
let state = emptyState();

try {
  const saved = localStorage.getItem(STORAGE_KEY);
  if (saved) state = validatedState(JSON.parse(saved));
} catch {
  loadError = true;
}

function emptyState() {
  return { schema: 1, shop: 'سپاس', products: [], sales: [], nextInvoice: 1 };
}

function icon(name) {
  return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + drawings[name] + '</svg>';
}

function escapeHtml(input) {
  return String(input).replace(/[&<>"']/g, character => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[character]
  ));
}

function digits(value) {
  return String(value).replace(/[۰-۹]/g, digit => '۰۱۲۳۴۵۶۷۸۹'.indexOf(digit))
    .replace(/[٠-٩]/g, digit => '٠١٢٣٤٥٦٧٨٩'.indexOf(digit));
}

function searchable(value) {
  return digits(value).replace(/ي/g, 'ی').replace(/ك/g, 'ک').trim().toLowerCase();
}

function number(value) { return formatter.format(value); }
function money(value) { return number(value) + ' تومان'; }
function date(value) { return dateFormatter.format(new Date(value)); }

function todayKey(value) {
  const day = new Date(value);
  return [day.getFullYear(), day.getMonth(), day.getDate()].join('-');
}

function invoiceCode(sale) { return 'فاکتور ' + number(sale.number); }

function isInteger(value, min, max) {
  return Number.isSafeInteger(value) && value >= min && value <= max;
}

function validText(value, limit, required = true) {
  return typeof value === 'string' && value.length <= limit && (!required || value.trim().length > 0);
}

function validatedState(source) {
  const invalid = () => new Error('فایل پشتیبان سپاس معتبر نیست.');
  if (!source || source.schema !== 1 || !validText(source.shop, 60) ||
      !Array.isArray(source.products) || !Array.isArray(source.sales) ||
      !isInteger(source.nextInvoice, 1, 1_000_000)) throw invalid();
  const ids = new Set();
  const codes = new Set();
  for (const product of source.products) {
    if (!product || !validText(product.id, 80) || !validText(product.name, 100) ||
        !validText(product.sku, 50) || !isInteger(product.stock, 0, MAX_STOCK) ||
        !isInteger(product.price, 0, MAX_PRICE)) throw invalid();
    const code = searchable(product.sku);
    if (ids.has(product.id) || codes.has(code)) throw invalid();
    ids.add(product.id);
    codes.add(code);
  }
  const invoices = new Set();
  for (const sale of source.sales) {
    if (!sale || !isInteger(sale.number, 1, source.nextInvoice - 1) ||
        invoices.has(sale.number) || !validText(sale.date, 40) ||
        !Number.isFinite(Date.parse(sale.date)) || !validText(sale.customer, 80, false) ||
        !payments.includes(sale.payment) || !Array.isArray(sale.items) || sale.items.length < 1 ||
        !isInteger(sale.total, 0, MAX_TOTAL)) throw invalid();
    let subtotal = 0;
    for (const item of sale.items) {
      if (!item || !validText(item.name, 100) || !validText(item.sku, 50) ||
          !isInteger(item.price, 0, MAX_PRICE) || !isInteger(item.quantity, 1, MAX_STOCK)) throw invalid();
      subtotal += item.price * item.quantity;
      if (!isInteger(subtotal, 0, MAX_TOTAL)) throw invalid();
    }
    if (!isInteger(sale.discount, 0, subtotal) || sale.total !== subtotal - sale.discount) throw invalid();
    invoices.add(sale.number);
  }
  return { schema: 1, shop: source.shop, products: source.products, sales: source.sales, nextInvoice: source.nextInvoice };
}

function save(next, replacing = false) {
  if (loadError && !replacing) return false;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    state = next;
    loadError = false;
    return true;
  } catch {
    return false;
  }
}

function toast(message) {
  clearTimeout(notificationTimer);
  notification.textContent = message;
  notificationTimer = setTimeout(() => { notification.textContent = ''; }, 3100);
}

function navTo(route) {
  current = route;
  render();
  window.scrollTo(0, 0);
}

function button(label, action, glyph, style = 'secondary') {
  return '<button type="button" class="button ' + style + '" data-action="' + action + '">' +
    (glyph ? icon(glyph) : '') + label + '</button>';
}

function emptyView(glyph, title, hint, action = '') {
  return '<div class="empty"><span class="row-icon">' + icon(glyph) + '</span><strong>' + title +
    '</strong><p>' + hint + '</p>' + action + '</div>';
}

function heading(title, hint = '', action = '') {
  return '<div class="heading"><div><h1>' + title + '</h1>' +
    (hint ? '<p>' + hint + '</p>' : '') + '</div>' + action + '</div>';
}

function stat(glyph, value, label) {
  return '<article class="stat"><span class="stat-icon">' + icon(glyph) + '</span><strong>' +
    number(value) + '</strong><span>' + label + '</span></article>';
}

function saleRow(sale) {
  return '<button type="button" class="row" data-action="invoice" data-key="' + sale.number + '">' +
    '<span class="row-icon">' + icon('receipt') + '</span><span class="describe"><strong>' + invoiceCode(sale) +
    '</strong><small>' + escapeHtml(sale.customer || 'مشتری حضوری') + ' · ' + escapeHtml(timeFormatter.format(new Date(sale.date))) +
    '</small></span><span class="value"><strong>' + money(sale.total) + '</strong><small>' + date(sale.date) + '</small></span></button>';
}

function homeView() {
  const today = todayKey(Date.now());
  const todaySales = state.sales.filter(sale => todayKey(sale.date) === today);
  const total = todaySales.reduce((sum, sale) => sum + sale.total, 0);
  const recent = [...state.sales].sort((a, b) => b.number - a.number).slice(0, 4);
  return '<section class="hero"><div class="hero-title"><span>فروش امروز</span><span>' + icon('clock') + ' ' +
    date(Date.now()) + '</span></div><h1>' + number(total) + '<small>تومان</small></h1>' +
    button('ثبت فروش', 'cash', 'plus', 'lime') + '</section><section class="stats">' +
    stat('receipt', todaySales.length, 'فاکتور امروز') + stat('box', state.products.length, 'تنوع کالا') +
    stat('alert', state.products.filter(product => product.stock <= lowStock).length, 'کالای کم‌موجود') +
    stat('register', state.products.reduce((sum, product) => sum + product.stock, 0), 'تعداد کل موجودی') +
    '</section><div class="section-head"><h2>آخرین فروش‌ها</h2><button type="button" data-action="history">همهٔ فروش‌ها</button></div>' +
    (recent.length ? '<div class="list">' + recent.map(saleRow).join('') + '</div>' :
      emptyView('receipt', 'هنوز فروشی ثبت نشده', 'فروش‌ها و رسیدهای شما اینجا نمایش داده می‌شود.'));
}

function searchInput(route, placeholder) {
  return '<label class="search">' + icon('search') + '<input type="search" data-search="' + route +
    '" aria-label="' + placeholder + '" placeholder="' + placeholder + '" value="' + escapeHtml(queries[route]) + '"></label>';
}

function filteredProducts(route) {
  const query = searchable(queries[route]);
  return state.products.filter(product => searchable(product.name + ' ' + product.sku).includes(query));
}

function productRow(product, forSale = false) {
  const low = product.stock <= lowStock ? ' class="low"' : '';
  const unavailable = forSale && product.stock <= (cart.get(product.id) || 0);
  return '<button type="button" class="row" data-action="' + (forSale ? 'add' : 'edit') + '" data-key="' +
    escapeHtml(product.id) + '"' + (unavailable ? ' disabled' : '') + '><span class="row-icon">' +
    icon(forSale ? 'plus' : 'box') + '</span><span class="describe"><strong>' + escapeHtml(product.name) +
    '</strong><small>کد ' + escapeHtml(product.sku) + '</small></span><span class="value"><strong>' +
    money(product.price) + '</strong><small' + low + '>موجودی ' + number(product.stock) + '</small></span></button>';
}

function productsList(route) {
  const products = filteredProducts(route);
  if (products.length) return products.map(product => productRow(product, route === 'cash')).join('');
  if (state.products.length) return emptyView('search', 'کالایی پیدا نشد', 'نام یا کد کالا را بررسی کنید.');
  return emptyView('box', 'فعلاً کالایی ندارید', 'نام، قیمت و موجودی اولیهٔ اولین کالا را وارد کنید.', button('افزودن کالا', 'new', 'plus'));
}

function stockView() {
  return heading('کالاها', 'قیمت و موجودی کالاهای فروشگاه', button('کالای جدید', 'new', 'plus', '')) +
    searchInput('stock', 'جست‌وجوی نام یا کد کالا') + '<div class="list" id="results">' + productsList('stock') + '</div>';
}

function linesInCart() {
  const lines = [];
  for (const [id, quantity] of cart) {
    const product = state.products.find(item => item.id === id);
    if (product) lines.push({ ...product, quantity });
  }
  return lines;
}

function cartView() {
  const lines = linesInCart();
  const subtotal = lines.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const contents = lines.map(item => '<div class="cart-item"><span><strong>' + escapeHtml(item.name) +
    '</strong><small>' + money(item.price * item.quantity) + '</small></span><span class="quantity">' +
    '<button type="button" data-action="add" data-key="' + escapeHtml(item.id) + '" aria-label="افزایش تعداد"' +
    (item.quantity >= item.stock ? ' disabled' : '') + '>' + icon('plus') + '</button><span>' +
    number(item.quantity) + '</span><button type="button" data-action="subtract" data-key="' +
    escapeHtml(item.id) + '" aria-label="کاهش تعداد">' + icon('minus') + '</button></span></div>').join('');
  return '<h2 class="cart-label">سبد فروش</h2><div class="cart-items">' +
    (contents || '<p class="muted">کالا را از فهرست انتخاب کنید.</p>') +
    '</div><div class="total"><span>جمع سبد</span><strong>' + money(subtotal) + '</strong></div>' +
    '<button type="button" class="button lime stretch" data-action="checkout"' +
    (lines.length ? '' : ' disabled') + '>' + icon('receipt') + 'ادامهٔ ثبت فروش</button>';
}

function cashView() {
  return heading('صندوق فروش', 'کالا را با نام یا کد پیدا کنید.') +
    '<div class="cash-grid"><div><div id="cash-search">' + searchInput('cash', 'جست‌وجوی نام یا کد کالا') + '</div>' +
    '<div class="list" id="results">' + productsList('cash') + '</div></div><section class="panel" id="cart">' +
    cartView() + '</section></div>';
}

function saleList() {
  const query = searchable(queries.history);
  const sales = state.sales.filter(sale => searchable(sale.number + ' ' + sale.customer).includes(query))
    .sort((a, b) => b.number - a.number);
  return sales.length ? sales.map(saleRow).join('') :
    emptyView('receipt', 'فاکتوری پیدا نشد', state.sales.length ? 'شمارهٔ فاکتور یا نام مشتری را بررسی کنید.' : 'فروش‌های ثبت‌شده اینجا نمایش داده می‌شوند.');
}

function historyView() {
  return heading('فروش‌ها', 'تاریخچهٔ فروش و رسید') + searchInput('history', 'شمارهٔ فاکتور یا نام مشتری') +
    '<div class="list" id="results">' + saleList() + '</div>';
}

function reportView() {
  const total = state.sales.reduce((sum, sale) => sum + sale.total, 0);
  const stockValue = state.products.reduce((sum, item) => sum + item.stock * item.price, 0);
  const critical = state.products.filter(product => product.stock <= lowStock).sort((a, b) => a.stock - b.stock);
  const paymentRows = payments.map(payment => {
    const sum = state.sales.reduce((amount, sale) => amount + (sale.payment === payment ? sale.total : 0), 0);
    return '<div class="row"><span class="describe"><strong>' + payment + '</strong></span><span class="value"><strong>' + money(sum) + '</strong></span></div>';
  });
  return heading('گزارش فروشگاه', 'خلاصهٔ همهٔ فروش‌ها و موجودی فعلی') +
    '<section class="stats">' + stat('report', total, 'کل فروش به تومان') + stat('receipt', state.sales.length, 'فاکتور ثبت‌شده') +
    stat('box', stockValue, 'ارزش موجودی به قیمت فروش، تومان') + stat('alert', critical.length, 'کالای کم‌موجود') +
    '</section><div class="section-head"><h2>فروش بر اساس پرداخت</h2></div><div class="list">' + paymentRows.join('') +
    '</div><div class="section-head"><h2>کالاهای کم‌موجود</h2></div><div class="list">' +
    (critical.length ? critical.map(product => productRow(product)).join('') :
      emptyView('box', 'کالای کم‌موجود ندارید', 'کالا با موجودی سه عدد یا کمتر اینجا نمایش داده می‌شود.')) + '</div>';
}

const screens = { home: homeView, stock: stockView, cash: cashView, history: historyView, report: reportView };

function render() {
  document.querySelector('.brand > span:last-child').firstChild.textContent = state.shop;
  navigation.innerHTML = routes.map(([route, title, glyph]) =>
    '<button type="button" data-action="' + route + '"' + (current === route ? ' aria-current="page"' : '') +
    '><span class="nav-icon">' + icon(glyph) + '</span>' + title + '</button>'
  ).join('');
  page.innerHTML = loadError ?
    heading('خواندن داده‌ها ممکن نیست') +
      emptyView('alert', 'اطلاعات فعلی حفظ شده است', 'برای بازیابی، فایل پشتیبان معتبر سپاس را انتخاب کنید.', button('بازیابی پشتیبان', 'import', 'download')) :
    screens[current]();
}

function renderResults() {
  const results = document.querySelector('#results');
  if (results) results.innerHTML = current === 'history' ? saleList() : productsList(current);
}

function openDialog(title, content) {
  dialog.innerHTML = '<div class="dialog-head"><h2>' + title + '</h2><button class="icon-button light" type="button" ' +
    'data-action="close" aria-label="بستن">' + icon('cross') + '</button></div>' + content;
  if (!dialog.open) dialog.showModal();
}

function field(label, name, value, mode = 'text', limit = 100, required = true) {
  return '<label class="field"><span>' + label + '</span><input name="' + name + '" value="' +
    escapeHtml(value) + '" inputmode="' + mode + '" maxlength="' + limit + '"' + (required ? ' required' : '') + '></label>';
}

function productDialog(id) {
  const previous = state.products.find(item => item.id === id);
  const item = previous || { name: '', sku: '', stock: 0, price: '' };
  openDialog(previous ? 'ویرایش کالا' : 'افزودن کالا', '<form data-form="product" data-key="' + escapeHtml(id || '') + '">' +
    field('نام کالا', 'name', item.name) + field('کد کالا یا بارکد', 'sku', item.sku, 'text', 50) +
    '<div class="fields two">' + field('قیمت فروش · تومان', 'price', item.price, 'numeric', 18) +
    field('موجودی · عدد', 'stock', item.stock, 'numeric', 18) +
    '</div><div class="form-error" role="alert"></div><div class="actions">' +
    '<button type="submit" class="button">ذخیره کالا</button>' +
    (previous ? '<button type="button" class="button danger" data-action="delete" data-key="' +
      escapeHtml(id) + '">حذف کالا</button>' : '') + '</div></form>');
}

function formInt(value) {
  const normalized = digits(value).replace(/[٬,\s]/g, '');
  return /^\d+$/.test(normalized) ? Number(normalized) : NaN;
}

function saveProduct(form, data) {
  const name = data.get('name').trim();
  const sku = data.get('sku').trim();
  const stock = formInt(data.get('stock'));
  const price = formInt(data.get('price'));
  const id = form.dataset.key;
  if (!name || !sku || !isInteger(stock, 0, MAX_STOCK) || !isInteger(price, 0, MAX_PRICE)) {
    return 'نام و کد را وارد کنید. قیمت و موجودی باید عدد صحیح در محدودهٔ مجاز باشند.';
  }
  if (state.products.some(item => item.id !== id && searchable(item.sku) === searchable(sku))) {
    return 'این کد قبلاً برای کالای دیگری ثبت شده است.';
  }
  const product = { id: id || crypto.randomUUID(), name, sku, stock, price };
  const products = id ? state.products.map(item => item.id === id ? product : item) : [...state.products, product];
  if (!save({ ...state, products })) return 'کالا ذخیره نشد. فضای ذخیره‌سازی را بررسی کنید.';
  if (cart.has(id)) {
    if (stock === 0) cart.delete(id);
    else cart.set(id, Math.min(cart.get(id), stock));
  }
  dialog.close();
  render();
  toast('کالا ذخیره شد');
}

function changeQuantity(id, increment) {
  const product = state.products.find(item => item.id === id);
  if (!product) return;
  const count = (cart.get(id) || 0) + increment;
  if (count > product.stock) {
    toast('موجودی این کالا کافی نیست');
    return;
  }
  if (count > 0) cart.set(id, count);
  else cart.delete(id);
  renderResults();
  document.querySelector('#cart').innerHTML = cartView();
}

function checkoutDialog() {
  const lines = linesInCart();
  if (!lines.length) return;
  const subtotal = lines.reduce((sum, item) => sum + item.price * item.quantity, 0);
  if (!isInteger(subtotal, 0, MAX_TOTAL)) {
    toast('مبلغ از سقف مجاز فاکتور بیشتر است');
    return;
  }
  openDialog('ثبت نهایی فروش', '<form data-form="sale">' + field('نام مشتری · اختیاری', 'customer', '', 'text', 80, false) +
    '<label class="field"><span>شیوهٔ پرداخت</span><select name="payment">' +
    payments.map(payment => '<option>' + payment + '</option>').join('') +
    '</select></label>' + field('تخفیف · تومان', 'discount', '0', 'numeric', 18) +
    '<div class="total"><span>جمع کالاها</span><strong>' + money(subtotal) +
    '</strong></div><div class="form-error" role="alert"></div>' +
    '<button type="submit" class="button lime stretch">ثبت و نمایش رسید</button></form>');
}

function submitSale(data) {
  const lines = linesInCart();
  const discount = formInt(data.get('discount'));
  const subtotal = lines.reduce((sum, item) => sum + item.price * item.quantity, 0);
  if (!lines.length || lines.some(item => item.quantity > item.stock)) return 'موجودی سبد را بررسی کنید.';
  if (!isInteger(discount, 0, subtotal) || !isInteger(subtotal, 0, MAX_TOTAL)) {
    return 'تخفیف باید بین صفر و جمع کالاها باشد.';
  }
  if (state.nextInvoice >= 1_000_000) return 'به سقف شمارهٔ فاکتور رسیده‌اید.';
  const sale = {
    number: state.nextInvoice, date: new Date().toISOString(), customer: data.get('customer').trim(),
    payment: data.get('payment'), discount, total: subtotal - discount,
    items: lines.map(({ name, sku, price, quantity }) => ({ name, sku, price, quantity }))
  };
  const products = state.products.map(product => ({ ...product, stock: product.stock - (cart.get(product.id) || 0) }));
  if (!save({ ...state, products, sales: [...state.sales, sale], nextInvoice: state.nextInvoice + 1 })) {
    return 'فروش ثبت نشد. فضای ذخیره‌سازی را بررسی کنید.';
  }
  cart.clear();
  render();
  invoiceDialog(sale.number);
}

function invoiceDialog(invoice) {
  const sale = state.sales.find(item => item.number === Number(invoice));
  if (!sale) return;
  openDialog(invoiceCode(sale), '<p class="muted">' + date(sale.date) + ' · ' + escapeHtml(sale.customer || 'مشتری حضوری') +
    ' · ' + sale.payment + '</p><div class="cart-items">' +
    sale.items.map(item => '<div class="cart-item"><span><strong>' + escapeHtml(item.name) + '</strong><small>' +
      number(item.quantity) + ' × ' + money(item.price) + '</small></span><strong>' +
      money(item.quantity * item.price) + '</strong></div>').join('') + '</div><p class="muted">تخفیف ' + money(sale.discount) +
    '</p><div class="total"><span>مبلغ نهایی</span><strong>' + money(sale.total) +
    '</strong></div><button type="button" class="button stretch" data-action="share" data-key="' +
    sale.number + '">اشتراک رسید</button>');
}

function settingsDialog() {
  openDialog('تنظیمات فروشگاه', '<form data-form="settings">' + field('نام فروشگاه', 'shop', state.shop, 'text', 60) +
    '<div class="form-error" role="alert"></div><button class="button" type="submit">ذخیره نام</button></form>' +
    '<div class="section-head"><h2>پشتیبان‌گیری</h2></div><p class="muted">اطلاعات روی همین دستگاه ذخیره می‌شود.</p>' +
    '<div class="actions">' + (loadError ? '' : button('ذخیرهٔ پشتیبان', 'export', 'download')) +
    button('بازیابی پشتیبان', 'import', '') + '</div>');
}

function exportBackup() {
  const data = JSON.stringify(state);
  if (window.SepasAndroid) {
    SepasAndroid.saveBackup(data);
    return;
  }
  const url = URL.createObjectURL(new Blob([data], { type: 'application/json' }));
  const link = document.createElement('a');
  link.href = url;
  link.download = 'Sepas-backup.json';
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

async function restoreBackup() {
  const file = backupFile.files[0];
  backupFile.value = '';
  if (!file) return;
  try {
    if (file.size > 5_000_000) throw new Error('حجم پشتیبان بیشتر از محدودهٔ مجاز است.');
    restoreText(await file.text());
  } catch (error) {
    toast(error.message);
  }
}

function restoreText(text) {
  try {
    const next = validatedState(JSON.parse(text));
    if (!window.confirm('کالاها و فروش‌های فعلی با اطلاعات فایل انتخاب‌شده جایگزین شوند؟')) return;
    if (!save(next, true)) throw new Error('بازیابی انجام نشد. فضای ذخیره‌سازی را بررسی کنید.');
    cart.clear();
    if (dialog.open) dialog.close();
    navTo('home');
    toast('پشتیبان بازیابی شد');
  } catch (error) {
    toast(error instanceof SyntaxError ? 'فایل پشتیبان قابل خواندن نیست.' : error.message);
  }
}

async function shareInvoice(invoice) {
  const sale = state.sales.find(item => item.number === Number(invoice));
  if (!sale) return;
  const text = [state.shop, invoiceCode(sale) + ' · ' + date(sale.date), sale.customer,
    ...sale.items.map(item => item.name + ' × ' + number(item.quantity) + ' · ' + money(item.quantity * item.price)),
    'تخفیف ' + money(sale.discount), 'مبلغ نهایی ' + money(sale.total), 'پرداخت ' + sale.payment
  ].filter(Boolean).join('\n');
  try {
    if (window.SepasAndroid) SepasAndroid.shareReceipt(text);
    else if (navigator.share) await navigator.share({ text });
    else {
      await navigator.clipboard.writeText(text);
      toast('رسید کپی شد');
    }
  } catch (error) {
    if (error.name !== 'AbortError') toast('اشتراک رسید انجام نشد');
  }
}

const actions = {
  home: () => navTo('home'), stock: () => navTo('stock'), cash: () => navTo('cash'),
  history: () => navTo('history'), report: () => navTo('report'),
  new: () => productDialog(), edit: productDialog,
  add: id => changeQuantity(id, 1), subtract: id => changeQuantity(id, -1),
  invoice: invoiceDialog, checkout: checkoutDialog, close: () => dialog.close(), settings: settingsDialog,
  import: () => window.SepasAndroid ? SepasAndroid.pickBackup() : backupFile.click(),
  export: exportBackup, share: shareInvoice,
  delete: id => {
    if (!window.confirm('این کالا از فهرست و سبد فروش حذف شود؟ رسیدهای ثبت‌شده حفظ می‌شوند.')) return;
    if (!save({ ...state, products: state.products.filter(item => item.id !== id) })) {
      toast('حذف کالا انجام نشد');
      return;
    }
    cart.delete(id);
    dialog.close();
    render();
    toast('کالا حذف شد');
  }
};

document.addEventListener('click', event => {
  const control = event.target.closest('button[data-action]');
  if (control && !control.disabled) actions[control.dataset.action](control.dataset.key);
});

function saveSettings(data) {
  const shop = data.get('shop').trim();
  if (!shop) return 'نام فروشگاه را وارد کنید.';
  if (!save({ ...state, shop })) return 'تنظیمات ذخیره نشد.';
  dialog.close();
  render();
  toast('نام فروشگاه ذخیره شد');
}

document.addEventListener('submit', event => {
  const form = event.target;
  const type = form.dataset.form;
  if (!type) return;
  event.preventDefault();
  const data = new FormData(form);
  const submit = { product: () => saveProduct(form, data), sale: () => submitSale(data), settings: () => saveSettings(data) };
  const message = submit[type]();
  if (message) form.querySelector('.form-error').textContent = message;
});

document.addEventListener('input', event => {
  const route = event.target.dataset.search;
  if (route) {
    queries[route] = event.target.value;
    renderResults();
  }
});

document.addEventListener('keydown', event => {
  if (event.key !== 'Enter' || event.target.dataset.search !== 'cash') return;
  const code = searchable(queries.cash);
  const product = state.products.find(item => searchable(item.sku) === code);
  if (product) changeQuantity(product.id, 1);
});

backupFile.addEventListener('change', restoreBackup);
window.sepasRestoreBase64 = encoded => {
  const bytes = Uint8Array.from(atob(encoded), character => character.charCodeAt(0));
  restoreText(new TextDecoder('utf-8').decode(bytes));
};
window.sepasBack = () => {
  if (dialog.open) {
    dialog.close();
    return true;
  }
  if (current === 'home') return false;
  navTo('home');
  return true;
};

document.querySelector('.brand-icon').innerHTML = icon('register');
document.querySelector('.topbar .icon-button').innerHTML = icon('settings');
render();
