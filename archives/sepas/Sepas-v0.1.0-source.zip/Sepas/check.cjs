'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const assets = path.join(__dirname, 'app/src/main/assets');
const source = fs.readFileSync(path.join(assets, 'app.js'), 'utf8');
const storage = new Map();
let storageWritable = true;

function runApp() {
  const elements = new Map();
  const listeners = {};
  const window = { scrollTo() {}, confirm: () => true };
  const document = {
    querySelector(selector) {
      if (!elements.has(selector)) {
        elements.set(selector, {
          innerHTML: '', firstChild: {}, open: false,
          showModal() { this.open = true; },
          close() { this.open = false; },
          addEventListener() {}
        });
      }
      return elements.get(selector);
    },
    addEventListener(event, listener) { listeners[event] = listener; }
  };
  const context = vm.createContext({
    document, window, crypto: require('node:crypto').webcrypto,
    TextDecoder, atob,
    setTimeout: () => 0, clearTimeout() {},
    localStorage: {
      getItem: key => storage.get(key),
      setItem: (key, value) => {
        if (!storageWritable) throw new Error('No space left');
        storage.set(key, value);
      }
    }
  });
  vm.runInContext(source, context);
  return { call: expression => vm.runInContext(expression, context), elements, listeners };
}

let { call, elements, listeners } = runApp();
assert.match(elements.get('#page').innerHTML, /هنوز فروشی ثبت نشده/);

call(`const makeProduct = (name, sku, price, stock, key = '') =>
  saveProduct({dataset: {key}}, new Map(Object.entries({name, sku, price, stock})));
  makeProduct('قهوه اسپرسو', '۱۲۳۴', '۱٬۵۰۰٬۰۰۰', '۵');`);
assert.match(call("makeProduct('کالای تکراری', '1234', '4500', '2')"), /قبلاً/);
assert.match(call("makeProduct('کالای نامعتبر', 'xyz', '4500', '-1')"), /محدوده/);
call(`makeProduct('شربت لیمو', '2150', '85000', '2');
  makeProduct('آب معدنی', '3101', '20000', '35');
  makeProduct('کیک شکلاتی', '4554', '175000', '8');
  navTo('cash'); queries.cash = '1234';`);
listeners.keydown({ key: 'Enter', target: { dataset: { search: 'cash' } } });
listeners.keydown({ key: 'Enter', target: { dataset: { search: 'cash' } } });
assert.equal(call('linesInCart()[0].quantity'), 2);
assert.match(call(`submitSale(new Map(Object.entries({customer: 'مشتری نمونه', discount: '9999999999', payment: 'کارت‌خوان'})))`), /بین صفر/);

const sale = `submitSale(new Map(Object.entries({customer: 'مشتری نمونه', discount: '۳۵۰٬۰۰۰', payment: 'کارت‌خوان'})))`;
storageWritable = false;
assert.match(call(sale), /فروش ثبت نشد/);
assert.equal(call('state.products[0].stock'), 5);
assert.equal(call('state.sales.length'), 0);
assert.equal(call('linesInCart()[0].quantity'), 2);
storageWritable = true;
assert.equal(call(sale), undefined);
assert.match(elements.get('#dialog').innerHTML, /۲٬۶۵۰٬۰۰۰/);
assert.equal(call('state.products[0].stock'), 3);
assert.equal(call('linesInCart().length'), 0);
call(`changeQuantity(state.products[2].id, 1);
  submitSale(new Map(Object.entries({customer: '', discount: '0', payment: 'نقدی'})));`);

({ call, elements, listeners } = runApp());
assert.equal(call('state.sales.length'), 2);
assert.equal(call('state.sales[0].total'), 2_650_000);
assert.equal(call('state.products[2].stock'), 34);
assert.match(elements.get('#page').innerHTML, /۲٬۶۷۰٬۰۰۰/);
assert.match(call('reportView()'), /۲٬۶۷۰٬۰۰۰/);

call(`saveProduct({dataset: {key: state.products[0].id}},
  new Map(Object.entries({name: 'اسپرسو ویژه', sku: '۱۲۳۴', price: '1550000', stock: '3'})));`);
assert.equal(call('state.sales[0].items[0].name'), 'قهوه اسپرسو');
assert.equal(call('state.sales[0].items[0].price'), 1_500_000);

call("restoreText('{}')");
assert.match(elements.get('#notification').textContent, /معتبر نیست/);
assert.equal(call('state.sales.length'), 2);
call("restoreText(JSON.stringify({...state, shop: 'فروشگاه نمونه'}))");
assert.match(elements.get('#notification').textContent, /بازیابی شد/);
assert.equal(call('state.shop'), 'فروشگاه نمونه');

const corrupt = { schema: 1, shop: 'سپاس', products: [], sales: [], nextInvoice: 0 };
storage.set('sepas.store.v1', JSON.stringify(corrupt));
const broken = runApp();
assert.match(broken.elements.get('#page').innerHTML, /خواندن داده‌ها ممکن نیست/);
assert.equal(storage.get('sepas.store.v1'), JSON.stringify(corrupt));

if (process.argv[2]) {
  call("restoreText(JSON.stringify({...state, shop: 'سپاس'}))");
  const html = fs.readFileSync(path.join(assets, 'index.html'), 'utf8')
    .replace('<span class="brand-icon" aria-hidden="true"></span>', '<span class="brand-icon" aria-hidden="true">' +
      elements.get('.brand-icon').innerHTML + '</span>')
    .replace('aria-label="پشتیبان‌گیری و تنظیمات"></button>', 'aria-label="پشتیبان‌گیری و تنظیمات">' +
      elements.get('.topbar .icon-button').innerHTML + '</button>')
    .replace('<main id="page"></main>', '<main id="page">' + elements.get('#page').innerHTML + '</main>')
    .replace('aria-label="صفحه‌های فروشگاه"></nav>', 'aria-label="صفحه‌های فروشگاه">' +
      elements.get('#navigation').innerHTML + '</nav>');
  fs.writeFileSync(process.argv[2], html);
}

console.log('PASS: RTL app logic, Persian input, duplicate SKU, barcode entry, discount, rejected storage write, checkout, stock decrement, persisted invoices, receipt snapshots, report totals, valid and invalid backups.');
