package ir.sepas.shop;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Collections;

public final class MainActivity extends Activity {
    private static final int IMAGE_REQUEST = 10;
    private static final int INK = 0xff4f234d;
    private WebView browser;
    private URI shop;
    private ValueCallback<Uri[]> fileCallback;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(INK);
        getWindow().setNavigationBarColor(INK);
        String previous = getPreferences(MODE_PRIVATE).getString("server", "");
        if (previous.isEmpty()) showConnection(previous, "");
        else connect(previous);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void showConnection(String address, String error) {
        destroyBrowser();
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setGravity(Gravity.CENTER_VERTICAL);
        form.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        form.setPadding(dp(24), dp(24), dp(24), dp(24));
        form.setBackgroundColor(0xfffffaf4);
        TextView title = new TextView(this);
        title.setText("سپاس");
        title.setTextColor(INK);
        title.setTextSize(31);
        form.addView(title);
        TextView label = new TextView(this);
        label.setText("آدرس HTTPS فروشگاه را وارد کنید.");
        label.setPadding(0, dp(14), 0, dp(12));
        form.addView(label);
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setTextDirection(View.TEXT_DIRECTION_LTR);
        input.setSingleLine(true);
        input.setText(address);
        input.setHint("https://");
        form.addView(input);
        Button start = new Button(this);
        start.setText("بازکردن فروشگاه");
        start.setOnClickListener(view -> connect(input.getText().toString()));
        form.addView(start);
        if (!error.isEmpty()) {
            TextView message = new TextView(this);
            message.setTextColor(0xff942b49);
            message.setText(error);
            form.addView(message);
        }
        scroll.addView(form);
        setContentView(scroll);
    }

    private URI parseShop(String address) throws URISyntaxException {
        URI url = new URI(address.trim());
        if (!"https".equalsIgnoreCase(url.getScheme()) || url.getHost() == null
                || url.getUserInfo() != null || url.getRawQuery() != null || url.getRawFragment() != null
                || (url.getPort() != -1 && (url.getPort() < 1 || url.getPort() > 65535))
                || (!url.getPath().isEmpty() && !"/".equals(url.getPath()))) {
            throw new URISyntaxException(address, "Expected an HTTPS origin");
        }
        return new URI("https", null, url.getHost(), url.getPort(), "/", null, null);
    }

    private boolean sameOrigin(Uri uri) {
        return "https".equalsIgnoreCase(uri.getScheme())
                && shop.getHost().equalsIgnoreCase(uri.getHost())
                && (shop.getPort() == -1 ? 443 : shop.getPort()) == (uri.getPort() == -1 ? 443 : uri.getPort());
    }

    private void connect(String address) {
        try {
            shop = parseShop(address);
        } catch (URISyntaxException error) {
            showConnection(address, "آدرس باید کامل باشد و با https:// شروع شود.");
            return;
        }
        destroyBrowser();
        WebView view = new WebView(this);
        browser = view;
        view.setBackgroundColor(Color.WHITE);
        WebSettings settings = view.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        CookieManager.getInstance().setAcceptThirdPartyCookies(view, false);

        view.setWebViewClient(new WebViewClient() {
            private boolean failed;

            @Override public boolean shouldOverrideUrlLoading(WebView web, WebResourceRequest request) {
                return !sameOrigin(request.getUrl());
            }

            @Override public WebResourceResponse shouldInterceptRequest(WebView web, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (sameOrigin(uri) || "blob".equals(uri.getScheme()) || "data".equals(uri.getScheme())) return null;
                return new WebResourceResponse("text/plain", "UTF-8", 403, "Forbidden",
                    Collections.emptyMap(), new ByteArrayInputStream(new byte[0]));
            }

            @Override public void onReceivedError(WebView web, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) connectionFailed();
            }

            @Override public void onReceivedHttpError(WebView web, WebResourceRequest request, WebResourceResponse error) {
                if (request.isForMainFrame()) connectionFailed();
            }

            private void connectionFailed() {
                failed = true;
                view.post(() -> {
                    if (browser == view) showConnection(shop.toString(), "اتصال به ویترین برقرار نشد.");
                });
            }

            @Override public void onPageFinished(WebView web, String url) {
                if (!failed && browser == view && sameOrigin(Uri.parse(url))) {
                    getPreferences(MODE_PRIVATE).edit().putString("server", shop.toString()).apply();
                    CookieManager.getInstance().flush();
                }
            }
        });

        view.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView web, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent select = new Intent(Intent.ACTION_GET_CONTENT);
                select.addCategory(Intent.CATEGORY_OPENABLE);
                select.setType("image/*");
                try {
                    startActivityForResult(select, IMAGE_REQUEST);
                } catch (ActivityNotFoundException error) {
                    fileCallback.onReceiveValue(null);
                    fileCallback = null;
                    Toast.makeText(MainActivity.this, "انتخاب‌کنندهٔ عکس در دسترس نیست.", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });
        setContentView(view);
        view.loadUrl(shop.toString());
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == IMAGE_REQUEST && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result, data));
            fileCallback = null;
        }
    }

    @Override public void onBackPressed() {
        WebView view = browser;
        if (view == null) {
            super.onBackPressed();
            return;
        }
        view.evaluateJavascript("window.sepasBack && window.sepasBack()", result -> {
            if (browser != view || "true".equals(result)) return;
            if (view.canGoBack()) view.goBack();
            else showConnection(shop.toString(), "");
        });
    }

    private void destroyBrowser() {
        if (fileCallback != null) {
            fileCallback.onReceiveValue(null);
            fileCallback = null;
        }
        if (browser != null) {
            browser.stopLoading();
            if (browser.getParent() instanceof android.view.ViewGroup) {
                ((android.view.ViewGroup) browser.getParent()).removeView(browser);
            }
            browser.destroy();
            browser = null;
        }
    }

    @Override protected void onDestroy() {
        destroyBrowser();
        super.onDestroy();
    }
}
