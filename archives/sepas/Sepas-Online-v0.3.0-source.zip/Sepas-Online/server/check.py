"""Exercise the storefront over HTTP with an isolated database."""
import base64
import json
import threading
from contextlib import closing
from http.cookiejar import CookieJar
from pathlib import Path
from tempfile import TemporaryDirectory
from urllib.error import HTTPError
from urllib.request import HTTPCookieProcessor, Request, build_opener
from wsgiref.simple_server import WSGIRequestHandler, make_server

from sepas import Sepas, ThreadedServer


class QuietHandler(WSGIRequestHandler):
    def log_message(self, format, *args):
        pass


with TemporaryDirectory() as directory:
    path = Path(directory) / "sepas.sqlite3"
    app = Sepas(path)
    app.provision_seller("09120000000", "seller", "seller@example.test", "seller-test-phrase")
    with make_server("127.0.0.1", 0, app, server_class=ThreadedServer, handler_class=QuietHandler) as http:
        base = f"http://127.0.0.1:{http.server_port}"
        worker = threading.Thread(target=http.serve_forever, daemon=True)
        worker.start()
        try:
            def client():
                return build_opener(HTTPCookieProcessor(CookieJar()))

            def request(opener, path, data=None, expected=200, csrf=True):
                headers = {"Content-Type": "application/json"}
                if csrf:
                    headers["X-Sepas-Request"] = "1"
                payload = None if data is None else json.dumps(data).encode()
                req = Request(base + path, headers=headers, data=payload)
                try:
                    response = opener.open(req, timeout=5)
                except HTTPError as error:
                    response = error
                with response:
                    raw = response.read()
                    assert response.code == expected, (path, response.code, raw[:1200])
                    if response.headers.get_content_type() == "application/json":
                        return json.loads(raw)
                    return raw

            guest, seller, customer, other = (client() for _ in range(4))
            index = request(guest, "/").decode()
            assert "پنل فروشنده" not in index and "seller" not in index
            assert request(guest, "/api/catalog") == []
            request(guest, "/api/seller/products", expected=403)
            request(guest, "/api/seller/orders", expected=403)
            request(guest, "/api/register", {}, expected=403, csrf=False)
            request(seller, "/api/seller/login", {"identity": "seller@example.test", "password": "incorrect"}, 401)
            request(seller, "/api/seller/login", {"identity": "seller@example.test", "password": "seller-test-phrase"})

            png = base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMB/6X8vHcAAAAASUVORK5CYII=")
            photo = "data:image/png;base64," + base64.b64encode(png).decode()
            product = {"name": "محصول تست", "category": "آزمایش", "description": "کالای نمونه",
                       "price": 1000, "sale_price": 900, "stock": 5, "active": False, "photo": photo}
            pid = request(seller, "/api/seller/products", product)["id"]
            assert request(guest, "/api/catalog") == []
            request(guest, f"/media/{pid}", expected=404)
            edit = {**product, "id": pid, "original_stock": 5, "active": True, "photo": None}
            request(seller, "/api/seller/products", edit)
            assert request(guest, "/api/catalog")[0]["has_photo"] == 1
            assert request(guest, f"/media/{pid}") == png

            auth = {"name": "خریدار نمونه", "phone": "۰۹۱۲۰۰۰۰۰۰۱", "username": "buyer",
                    "password": "customer-test-phrase", "role": "seller"}
            request(customer, "/api/register", auth)
            assert request(customer, "/api/session")["role"] == "customer"
            request(customer, "/api/seller/products", product, 403)
            request(customer, "/api/seller/orders", expected=403)
            request(customer, "/api/seller/login", {"identity": "buyer", "password": auth["password"]}, 401)
            request(other, "/api/register", {**auth, "phone": "09120000002", "username": "buyer2"})

            cart = {"key": "request-1", "address": "نشانی نمونه", "items": [{"id": pid, "quantity": 4, "unit_price": 900}]}
            request(guest, "/api/orders", cart, 403)
            request(other, "/api/orders", {**cart, "items": [{"id": pid, "quantity": 1, "unit_price": 1}]}, 409)
            code = request(customer, "/api/orders", cart, 201)["code"]
            assert request(customer, "/api/orders", cart)["code"] == code
            assert request(guest, "/api/catalog")[0]["stock"] == 1
            request(seller, "/api/seller/products", edit, 409)
            request(other, "/api/orders", cart, 409)
            assert request(other, "/api/orders") == []
            mine = request(customer, "/api/orders")
            assert len(mine) == 1 and mine[0]["total"] == 3600 and mine[0]["status"] == "pending"
            seller_order, = request(seller, "/api/seller/orders")
            assert seller_order["code"] == code
            request(customer, "/api/seller/orders", {"id": seller_order["id"], "status": "cancelled"}, 403)
            request(seller, "/api/seller/orders", {"id": seller_order["id"], "status": "cancelled"})
            request(seller, "/api/seller/orders", {"id": seller_order["id"], "status": "cancelled"}, 409)
            assert request(guest, "/api/catalog")[0]["stock"] == 5
            assert request(customer, "/api/orders")[0]["status"] == "cancelled"
            request(seller, "/api/logout", {})
            request(seller, "/api/seller/products", expected=403)
            request(customer, "/api/logout", {})
            request(customer, "/api/customer/login", {"identity": "+989120000001", "password": auth["password"]})
            assert request(customer, "/api/orders")[0]["code"] == code
            with closing(app.connect()) as db:
                assert db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
        finally:
            http.shutdown()
            worker.join()

print("PASS: public storefront, hidden-entry markup, image upload, customer and seller login, authorization, orders, payment-total validation, stock, idempotency, cancellation, and persistence.")
