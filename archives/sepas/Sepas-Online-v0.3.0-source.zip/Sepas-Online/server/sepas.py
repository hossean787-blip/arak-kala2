"""Server for the Sepas storefront and seller panel."""
import argparse
import base64
import binascii
import getpass
import hashlib
import hmac
import json
import re
import secrets
import sqlite3
import time
from contextlib import closing
from http.cookies import CookieError, SimpleCookie
from pathlib import Path
from socketserver import ThreadingMixIn
from wsgiref.simple_server import WSGIServer, make_server

ROOT = Path(__file__).resolve().parent
STATIC = ROOT / "static"
PRODUCT_FIELDS = (
    "id, name, category, description, price, sale_price, stock, active,"
    " photo IS NOT NULL AS has_photo"
)
STATES = {
    "pending": {"confirmed", "cancelled"},
    "confirmed": {"shipped", "cancelled"},
    "shipped": {"delivered"},
    "delivered": set(),
    "cancelled": set(),
}
MAX_PHOTO = 2_000_000
MAX_BODY = 3_000_000
COOKIE = "sepas_session"


class ApiError(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status = status


def text_field(payload, field, limit, *, required=True):
    value = payload.get(field, "")
    if not isinstance(value, str) or "\x00" in value or re.search(r"[\ud800-\udfff]", value):
        raise ApiError("400 Bad Request", "اطلاعات واردشده معتبر نیست.")
    value = value.strip()
    if len(value) > limit or (required and not value):
        raise ApiError("400 Bad Request", "فیلدهای فرم را کامل و بررسی کنید.")
    return value


def integer(payload, field, low, high):
    value = payload.get(field)
    if type(value) is not int or not low <= value <= high:
        raise ApiError("400 Bad Request", "مقدار عددی واردشده معتبر نیست.")
    return value


def normalize_phone(value):
    value = str(value).translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789"))
    value = re.sub(r"[\s-]", "", value)
    for prefix in ("0098", "+98", "98"):
        if value.startswith(prefix):
            value = "0" + value[len(prefix):]
            break
    return value if re.fullmatch(r"09[0-9]{9}", value) else None


def password_hash(password, salt=None):
    salt = salt or secrets.token_hex(16)
    value = hashlib.scrypt(password.encode(), salt=bytes.fromhex(salt), n=16384, r=8, p=1)
    return salt + ":" + value.hex()


def new_password(payload):
    value = payload.get("password")
    if not isinstance(value, str) or not 8 <= len(value) <= 128 or re.search(r"[\ud800-\udfff]", value):
        raise ApiError("400 Bad Request", "رمز عبور باید ۸ تا ۱۲۸ نویسه داشته باشد.")
    return value


def username_field(payload):
    username = text_field(payload, "username", 30, required=False).lower()
    if username and not re.fullmatch(r"[a-z][a-z0-9_.-]{2,29}", username):
        raise ApiError("400 Bad Request", "نام کاربری را با حرف انگلیسی شروع کنید و حداقل ۳ نویسه وارد کنید.")
    return username or None


def photo_from_value(value):
    if not isinstance(value, str) or len(value) > MAX_BODY:
        raise ApiError("400 Bad Request", "عکس محصول معتبر نیست.")
    match = re.fullmatch(r"data:(image/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)", value)
    if not match:
        raise ApiError("400 Bad Request", "فرمت عکس باید JPG، PNG یا WebP باشد.")
    try:
        data = base64.b64decode(match.group(2), validate=True)
    except binascii.Error as error:
        raise ApiError("400 Bad Request", "عکس محصول خوانده نشد.") from error
    mime = match.group(1)
    valid = {
        "image/jpeg": data.startswith(b"\xff\xd8\xff") and data.endswith(b"\xff\xd9"),
        "image/png": data.startswith(b"\x89PNG\r\n\x1a\n"),
        "image/webp": data.startswith(b"RIFF") and data[8:12] == b"WEBP",
    }
    if not 0 < len(data) <= MAX_PHOTO or not valid[mime]:
        raise ApiError("400 Bad Request", "فایل عکس نامعتبر یا بزرگ‌تر از ۲ مگابایت است.")
    return mime, data


class Sepas:
    def __init__(self, path, secure=False):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.secure = secure
        with closing(self.connect()) as db:
            db.execute("PRAGMA journal_mode = WAL")
            db.executescript((ROOT / "schema.sql").read_text(encoding="utf-8"))
        self.dummy_hash = password_hash(secrets.token_hex(16))
        self.routes = {
            ("GET", "/api/session"): self.session,
            ("GET", "/api/catalog"): self.catalog,
            ("GET", "/api/orders"): self.customer_orders,
            ("GET", "/api/seller/products"): self.seller_products,
            ("GET", "/api/seller/orders"): self.seller_orders,
            ("POST", "/api/register"): self.register,
            ("POST", "/api/customer/login"): self.customer_login,
            ("POST", "/api/seller/login"): self.seller_login,
            ("POST", "/api/logout"): self.logout,
            ("POST", "/api/orders"): self.order,
            ("POST", "/api/seller/products"): self.save_product,
            ("POST", "/api/seller/orders"): self.change_order,
        }

    def connect(self):
        db = sqlite3.connect(self.path, timeout=10)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys = ON")
        return db

    def __call__(self, environ, start_response):
        try:
            status, headers, body = self.handle(environ)
        except ApiError as error:
            status, headers, body = self.response({"error": str(error)}, status=error.status)
        except sqlite3.OperationalError:
            status, headers, body = self.response(
                {"error": "سرور موقتاً در دسترس نیست. دوباره تلاش کنید."},
                status="503 Service Unavailable",
            )
        headers.extend([
            ("Content-Length", str(len(body))),
            ("X-Content-Type-Options", "nosniff"),
            ("Referrer-Policy", "same-origin"),
            ("Content-Security-Policy", "default-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'; img-src 'self' data: blob:"),
        ])
        start_response(status, headers)
        return [body]

    def handle(self, environ):
        method = environ.get("REQUEST_METHOD")
        path = environ.get("PATH_INFO", "")
        static = {
            "/": ("index.html", "text/html; charset=utf-8"),
            "/shop.css": ("shop.css", "text/css; charset=utf-8"),
            "/shop.js": ("shop.js", "text/javascript; charset=utf-8"),
            "/font-regular.ttf": ("font-regular.ttf", "font/ttf"),
            "/font-bold.ttf": ("font-bold.ttf", "font/ttf"),
        }
        if method == "GET" and path in static:
            filename, kind = static[path]
            return "200 OK", [("Content-Type", kind), ("Cache-Control", "no-cache")], (STATIC / filename).read_bytes()
        photo = re.fullmatch(r"/media/([1-9][0-9]{0,14})", path)
        handler = self.routes.get((method, path))
        if not handler and not (photo and method == "GET"):
            raise ApiError("404 Not Found", "صفحه پیدا نشد.")
        with closing(self.connect()) as db:
            account, digest = self.account(db, environ)
            if photo:
                return self.media(db, account, int(photo.group(1)))
            if method == "POST":
                payload = self.read_json(environ)
            else:
                payload = {}
            return handler(db, account, payload, environ, digest)

    def read_json(self, environ):
        if (environ.get("HTTP_X_SEPAS_REQUEST") != "1"
                or environ.get("HTTP_SEC_FETCH_SITE") == "cross-site"
                or environ.get("CONTENT_TYPE", "").split(";")[0] != "application/json"):
            raise ApiError("403 Forbidden", "درخواست معتبر نیست.")
        try:
            length = int(environ.get("CONTENT_LENGTH", "0"))
            if not 0 < length <= MAX_BODY:
                raise ApiError("413 Payload Too Large", "حجم درخواست بیش از حد مجاز است.")
            data = json.loads(environ["wsgi.input"].read(length))
        except (ValueError, UnicodeError, RecursionError) as error:
            raise ApiError("400 Bad Request", "درخواست قابل‌خواندن نیست.") from error
        if not isinstance(data, dict):
            raise ApiError("400 Bad Request", "درخواست نامعتبر است.")
        return data

    @staticmethod
    def response(value, *, status="200 OK", headers=()):
        return status, [("Content-Type", "application/json; charset=utf-8"),
                        ("Cache-Control", "no-store"), *headers], json.dumps(value, ensure_ascii=False).encode()

    def account(self, db, environ):
        try:
            cookie = SimpleCookie(environ.get("HTTP_COOKIE", "")).get(COOKIE)
        except CookieError:
            cookie = None
        if not cookie or not re.fullmatch(r"[A-Za-z0-9_-]{43}", cookie.value):
            return None, None
        digest = hashlib.sha256(cookie.value.encode()).hexdigest()
        account = db.execute(
            "SELECT a.id, a.full_name, a.phone, a.role FROM sessions s"
            " JOIN accounts a ON a.id = s.account_id WHERE s.digest = ? AND s.expires > ?",
            (digest, int(time.time())),
        ).fetchone()
        return account, digest

    @staticmethod
    def require(account, role):
        if account is None or account["role"] != role:
            raise ApiError("403 Forbidden", "برای ادامه با حساب مربوط وارد شوید.")

    def cookie(self, token, seconds):
        suffix = "; Secure" if self.secure else ""
        return ("Set-Cookie", f"{COOKIE}={token}; Path=/; Max-Age={seconds}; HttpOnly; SameSite=Strict{suffix}")

    def create_session(self, db, account_id, role, digest):
        token = secrets.token_urlsafe(32)
        now = int(time.time())
        seconds = 43_200 if role == "seller" else 604_800
        with db:
            db.execute("DELETE FROM sessions WHERE expires <= ? OR digest = ?", (now, digest))
            db.execute("INSERT INTO sessions VALUES (?, ?, ?)",
                       (hashlib.sha256(token.encode()).hexdigest(), account_id, now + seconds))
        return self.response({"role": role}, headers=[self.cookie(token, seconds)])

    def session(self, db, account, payload, environ, digest):
        return self.response(dict(account) if account else None)

    def throttle(self, db, environ, identity="", role=""):
        key = environ.get("REMOTE_ADDR", "") + "|" + role
        bucket = int(time.time()) // 900
        keys = [(key, 60)]
        if identity:
            keys.append((role + "|account|" + identity, 12))
        with db:
            db.execute("BEGIN IMMEDIATE")
            db.execute("DELETE FROM auth_attempts WHERE bucket < ?", (bucket - 1,))
            for limit_key, limit in keys:
                row = db.execute("SELECT attempts FROM auth_attempts WHERE key = ? AND bucket = ?",
                                 (limit_key, bucket)).fetchone()
                if row and row["attempts"] >= limit:
                    raise ApiError("429 Too Many Requests", "تعداد تلاش‌ها زیاد شده است. کمی بعد دوباره امتحان کنید.")
                db.execute(
                    "INSERT INTO auth_attempts VALUES (?, ?, 1) ON CONFLICT(key) DO UPDATE SET"
                    " attempts = CASE WHEN bucket = excluded.bucket THEN attempts + 1 ELSE 1 END,"
                    " bucket = excluded.bucket", (limit_key, bucket)
                )

    def login(self, db, environ, payload, digest, role):
        identity = text_field(payload, "identity", 160).lower()
        normalized = normalize_phone(identity) or identity
        self.throttle(db, environ, normalized, role)
        password = new_password(payload)
        account = db.execute(
            "SELECT id, password FROM accounts WHERE role = ? AND (phone = ? OR username = ? OR email = ?)",
            (role, normalized, normalized, normalized),
        ).fetchone()
        saved = account["password"] if account else self.dummy_hash
        if not hmac.compare_digest(password_hash(password, saved.split(":")[0]), saved) or not account:
            raise ApiError("401 Unauthorized", "نام کاربری یا رمز عبور درست نیست.")
        return self.create_session(db, account["id"], role, digest)

    def customer_login(self, db, account, payload, environ, digest):
        return self.login(db, environ, payload, digest, "customer")

    def seller_login(self, db, account, payload, environ, digest):
        return self.login(db, environ, payload, digest, "seller")

    def register(self, db, account, payload, environ, digest):
        self.throttle(db, environ, role="register")
        phone = normalize_phone(text_field(payload, "phone", 25))
        if not phone:
            raise ApiError("400 Bad Request", "شمارهٔ موبایل ایران معتبر نیست.")
        name = text_field(payload, "name", 90)
        username = username_field(payload)
        password = password_hash(new_password(payload))
        try:
            with db:
                result = db.execute(
                    "INSERT INTO accounts (role, phone, username, full_name, password) VALUES ('customer', ?, ?, ?, ?)",
                    (phone, username, name, password),
                )
        except sqlite3.IntegrityError as error:
            raise ApiError("409 Conflict", "این موبایل یا نام کاربری ثبت شده است.") from error
        return self.create_session(db, result.lastrowid, "customer", digest)

    def logout(self, db, account, payload, environ, digest):
        with db:
            db.execute("DELETE FROM sessions WHERE digest = ?", (digest,))
        return self.response({"ok": True}, headers=[self.cookie("", 0)])

    def catalog(self, db, account, payload, environ, digest):
        return self.response([dict(row) for row in db.execute(
            f"SELECT {PRODUCT_FIELDS} FROM products WHERE active = 1 ORDER BY id DESC"
        )])

    def media(self, db, account, product_id):
        row = db.execute(
            "SELECT photo_type, photo FROM products WHERE id = ? AND (active = 1 OR ? = 'seller')",
            (product_id, account["role"] if account else ""),
        ).fetchone()
        if not row or row["photo"] is None:
            raise ApiError("404 Not Found", "عکس محصول پیدا نشد.")
        return "200 OK", [("Content-Type", row["photo_type"]), ("Cache-Control", "no-store")], row["photo"]

    def seller_products(self, db, account, payload, environ, digest):
        self.require(account, "seller")
        return self.response([dict(row) for row in db.execute(
            f"SELECT {PRODUCT_FIELDS} FROM products ORDER BY id DESC"
        )])

    def save_product(self, db, account, payload, environ, digest):
        self.require(account, "seller")
        name = text_field(payload, "name", 100)
        category = text_field(payload, "category", 80)
        description = text_field(payload, "description", 2000, required=False)
        price = integer(payload, "price", 0, 999_999_999)
        sale_price = None if payload.get("sale_price") is None else integer(payload, "sale_price", 0, price - 1)
        stock = integer(payload, "stock", 0, 100_000)
        if type(payload.get("active")) is not bool:
            raise ApiError("400 Bad Request", "وضعیت انتشار معتبر نیست.")
        active = int(payload["active"])
        editing = payload.get("id") is not None
        product_id = integer(payload, "id", 1, 999_999_999) if editing else None
        new_photo = photo_from_value(payload["photo"]) if payload.get("photo") else None
        values = (name, category, description, price, sale_price, stock, active)
        with db:
            if editing:
                db.execute("BEGIN IMMEDIATE")
                expected_stock = integer(payload, "original_stock", 0, 100_000)
                row = db.execute("SELECT stock FROM products WHERE id = ?", (product_id,)).fetchone()
                if not row:
                    raise ApiError("404 Not Found", "محصول پیدا نشد.")
                if row["stock"] != expected_stock:
                    raise ApiError("409 Conflict", "موجودی تغییر کرده است. محصول را دوباره باز کنید.")
                db.execute(
                    "UPDATE products SET name=?,category=?,description=?,price=?,sale_price=?,stock=?,active=? WHERE id=?",
                    (*values, product_id),
                )
            else:
                product_id = db.execute(
                    "INSERT INTO products (name,category,description,price,sale_price,stock,active) VALUES (?,?,?,?,?,?,?)",
                    values,
                ).lastrowid
            if new_photo:
                db.execute("UPDATE products SET photo_type=?, photo=? WHERE id=?", (*new_photo, product_id))
            elif payload.get("remove_photo") is True:
                db.execute("UPDATE products SET photo_type=NULL, photo=NULL WHERE id=?", (product_id,))
        return self.response({"id": product_id})

    def order(self, db, account, payload, environ, digest):
        self.require(account, "customer")
        token = text_field(payload, "key", 70)
        address = text_field(payload, "address", 400)
        cart = payload.get("items")
        if not isinstance(cart, list) or not 1 <= len(cart) <= 100:
            raise ApiError("400 Bad Request", "سبد خرید معتبر نیست.")
        requested = {}
        for item in cart:
            if not isinstance(item, dict):
                raise ApiError("400 Bad Request", "سبد خرید معتبر نیست.")
            product_id = integer(item, "id", 1, 999_999_999)
            if product_id in requested:
                raise ApiError("400 Bad Request", "کالای تکراری در سبد خرید.")
            requested[product_id] = (integer(item, "quantity", 1, 100), integer(item, "unit_price", 0, 999_999_999))
        with db:
            db.execute("BEGIN IMMEDIATE")
            existing = db.execute("SELECT code FROM orders WHERE account_id=? AND request_key=?",
                                  (account["id"], token)).fetchone()
            if existing:
                return self.response({"code": existing["code"]})
            lines = []
            total = 0
            for product_id, (quantity, displayed_price) in requested.items():
                product = db.execute(
                    "SELECT id, name, price, sale_price, stock FROM products WHERE id = ? AND active = 1",
                    (product_id,),
                ).fetchone()
                if not product or quantity > product["stock"]:
                    raise ApiError("409 Conflict", "موجودی یک یا چند کالا تغییر کرده. سبد را بررسی کنید.")
                price = product["sale_price"] if product["sale_price"] is not None else product["price"]
                if price != displayed_price:
                    raise ApiError("409 Conflict", "قیمت کالا تغییر کرده است. سبد را دوباره باز کنید.")
                lines.append((product_id, product["name"], quantity, price))
                total += price * quantity
            code = "S-" + secrets.token_hex(8).upper()
            order_id = db.execute(
                "INSERT INTO orders (code,account_id,request_key,status,total,name,phone,address)"
                " VALUES (?,?,?,'pending',?,?,?,?)",
                (code, account["id"], token, total, account["full_name"], account["phone"], address),
            ).lastrowid
            for line in lines:
                db.execute("INSERT INTO order_items VALUES (?,?,?,?,?)", (order_id, *line))
                db.execute("UPDATE products SET stock = stock - ? WHERE id = ?", (line[2], line[0]))
        return self.response({"code": code}, status="201 Created")

    def order_rows(self, db, owner=None):
        query = "SELECT id, code, status, total, name, phone, address, created_at FROM orders"
        parameters = ()
        if owner is not None:
            query += " WHERE account_id = ?"
            parameters = (owner,)
        orders = []
        for row in db.execute(query + " ORDER BY id DESC LIMIT 100", parameters):
            order = dict(row)
            order["items"] = [dict(item) for item in db.execute(
                "SELECT name, quantity, unit_price FROM order_items WHERE order_id=?",
                (row["id"],),
            )]
            if owner is None:
                order["next"] = sorted(STATES[order["status"]])
            orders.append(order)
        return self.response(orders)

    def customer_orders(self, db, account, payload, environ, digest):
        self.require(account, "customer")
        return self.order_rows(db, account["id"])

    def seller_orders(self, db, account, payload, environ, digest):
        self.require(account, "seller")
        return self.order_rows(db)

    def change_order(self, db, account, payload, environ, digest):
        self.require(account, "seller")
        order_id = integer(payload, "id", 1, 999_999_999)
        status = text_field(payload, "status", 20)
        with db:
            db.execute("BEGIN IMMEDIATE")
            current = db.execute("SELECT status FROM orders WHERE id=?", (order_id,)).fetchone()
            if not current:
                raise ApiError("404 Not Found", "سفارش پیدا نشد.")
            if status not in STATES[current["status"]]:
                raise ApiError("409 Conflict", "این تغییر وضعیت مجاز نیست.")
            if status == "cancelled":
                for item in db.execute("SELECT product_id,quantity FROM order_items WHERE order_id=?", (order_id,)):
                    db.execute("UPDATE products SET stock = stock + ? WHERE id=?", (item["quantity"], item["product_id"]))
            db.execute("UPDATE orders SET status=? WHERE id=?", (status, order_id))
        return self.response({"ok": True})

    def provision_seller(self, phone, username, email, password):
        normalized = normalize_phone(phone)
        username = username_field({"username": username})
        if not normalized or not username:
            raise ApiError("400 Bad Request", "موبایل و نام کاربری فروشنده را بررسی کنید.")
        email = email.strip().lower() or None
        if email and not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
            raise ApiError("400 Bad Request", "ایمیل معتبر نیست.")
        with closing(self.connect()) as db, db:
            db.execute(
                "INSERT INTO accounts (role,phone,username,email,full_name,password) VALUES ('seller',?,?,?,?,?)",
                (normalized, username, email, username, password_hash(new_password({"password": password}))),
            )


class ThreadedServer(ThreadingMixIn, WSGIServer):
    daemon_threads = True


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--database", default=str(ROOT / "data" / "sepas.sqlite3"))
    commands = parser.add_subparsers(dest="command", required=True)
    setup = commands.add_parser("create-seller")
    setup.add_argument("--phone", required=True)
    setup.add_argument("--username", required=True)
    setup.add_argument("--email", default="")
    serve = commands.add_parser("serve")
    serve.add_argument("--host", default="127.0.0.1")
    serve.add_argument("--port", default=8080, type=int)
    serve.add_argument("--secure", action="store_true", help="Set Secure cookies when running behind HTTPS")
    args = parser.parse_args()
    app = Sepas(args.database, secure=getattr(args, "secure", False))
    if args.command == "create-seller":
        password = getpass.getpass("رمز فروشنده: ")
        if password != getpass.getpass("تکرار رمز: "):
            parser.error("رمزها یکسان نیستند.")
        try:
            app.provision_seller(args.phone, args.username, args.email, password)
        except (ApiError, sqlite3.IntegrityError) as error:
            parser.error(str(error))
        print("حساب فروشنده ساخته شد.")
    else:
        with make_server(args.host, args.port, app, server_class=ThreadedServer) as server:
            print(f"Sepas listening on {args.host}:{args.port}", flush=True)
            server.serve_forever()


if __name__ == "__main__":
    main()
