"""WSGI entry point for an HTTPS-backed server."""
import os
from pathlib import Path

from sepas import Sepas

database = os.environ.get("SEPAS_DB", str(Path(__file__).resolve().parent / "data" / "sepas.sqlite3"))
application = Sepas(database, secure=True)
