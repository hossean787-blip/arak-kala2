'use strict';

const assert = require('node:assert/strict');
const vm = require('node:vm');
const path = require('node:path');
const fs = require('node:fs');

const elements = new Map();
const calls = [];
let clock = 1000;
const document = {
  querySelector(selector) {
    if (!elements.has(selector)) {
      elements.set(selector, {
        innerHTML: '', textContent: '',
        addEventListener(event, listener) { this[event] = listener; }
      });
    }
    return elements.get(selector);
  },
  addEventListener() {}
};
const product = {
  id: 1, name: '<ساعت نمونه>', category: 'اکسسوری', description: 'توضیح کالا',
  price: 250000, sale_price: 200000, stock: 3, has_photo: 1
};
const context = vm.createContext({
  document, Intl, Date: class extends Date { static now() { return clock; } },
  localStorage: { getItem: () => null, setItem() {} },
  window: { scrollTo() {} }, setTimeout() {}, clearTimeout() {},
  fetch: async url => {
    calls.push(url);
    const data = url === '/api/catalog' ? [product] : null;
    return { ok: true, json: async () => data };
  }
});

(async () => {
  vm.runInContext(fs.readFileSync(path.join(__dirname, 'static/shop.js'), 'utf8'), context);
  await new Promise(resolve => setImmediate(resolve));
  const main = document.querySelector('#main');
  const brand = document.querySelector('#brand');
  assert.match(main.innerHTML, /فروشگاه سپاس/);
  assert.match(main.innerHTML, /&lt;ساعت نمونه&gt;/);
  assert.match(main.innerHTML, /\/media\/1/);
  assert.ok(!main.innerHTML.includes('ورود فروشنده'));
  const evaluate = input => vm.runInContext(input, context);
  evaluate('actions.product(1)');
  assert.match(main.innerHTML, /توضیح کالا/);
  evaluate('actions["add-detail"](1)');
  assert.equal(evaluate('cart[1]'), 1);
  assert.equal(document.querySelector('#cart-badge').textContent, '۱');
  evaluate('go("cart")');
  assert.match(main.innerHTML, /ورود برای ثبت سفارش/);
  assert.equal(evaluate('window.sepasBack()'), true);

  for (let i = 0; i < 4; i++) {
    clock += 180;
    await brand.click();
    assert.doesNotMatch(main.innerHTML, /ورود فروشنده/);
  }
  clock += 180;
  await brand.click();
  assert.match(main.innerHTML, /ورود فروشنده/);
  assert.ok(!calls.some(url => url.startsWith('/api/seller/')));

  evaluate('go("shop")');
  for (let i = 0; i < 5; i++) {
    clock += 1100;
    await brand.click();
  }
  assert.doesNotMatch(main.innerHTML, /ورود فروشنده/);
  console.log('PASS: customer starts at the catalog, escaped product content, guest cart, five quick taps, slow taps, and permission-aware seller entry.');
})().catch(error => { console.error(error); process.exitCode = 1; });
