'use strict';

const main = document.querySelector('#main');
const note = document.querySelector('#message');
const badge = document.querySelector('#cart-badge');
const numbers = new Intl.NumberFormat('fa-IR');
const dates = new Intl.DateTimeFormat('fa-IR', { dateStyle: 'medium' });
const states = { pending: 'در انتظار تأیید', confirmed: 'تأیید شده', shipped: 'ارسال شده', delivered: 'تحویل شده', cancelled: 'لغو شده' };
let user = null;
let catalog = [];
let sellerProducts = [];
let orders = [];
let screen = 'shop';
let activeProduct;
let category = '';
let query = '';
let sort = 'new';
let quantity = 1;
let cart = {};
let orderKey = '';
let afterLogin = 'account';
let lastTap = 0;
let taps = 0;
let noticeTimer;
try {
  const saved = JSON.parse(localStorage.getItem('sepas.online.cart') || '{}');
  orderKey = typeof saved.key === 'string' ? saved.key : '';
  cart = Object.fromEntries(Object.entries(saved.items || {}).filter(([id, count]) =>
    /^[1-9]\d{0,8}$/.test(id) && Number.isInteger(count) && count > 0 && count <= 100));
} catch {}

function esc(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
}
function num(value) { return numbers.format(value); }
function money(value) { return num(value) + ' تومان'; }
function validPrice(product) { return product.sale_price ?? product.price; }
function button(action, label, key = '', style = 'secondary', disabled = false) {
  return '<button type="button" class="' + style + '" data-action="' + action + '" data-key="' + esc(key) + '"' +
    (disabled ? ' disabled' : '') + '>' + label + '</button>';
}
function field(label, name, value = '', options = '') {
  return '<label>' + label + '<input name="' + name + '" value="' + esc(value) + '" ' + options + '></label>';
}
function formError() { return '<p class="error" role="alert"></p>'; }
function empty(label) { return '<div class="empty">' + label + '</div>'; }
function heading(title, action = '') { return '<div class="page-heading"><h1>' + title + '</h1>' + action + '</div>'; }
function notice(text) {
  clearTimeout(noticeTimer);
  note.textContent = text;
  noticeTimer = setTimeout(() => { note.textContent = ''; }, 3400);
}
async function api(path, payload) {
  const options = payload === undefined ? {} : {
    method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Sepas-Request': '1' }, body: JSON.stringify(payload)
  };
  const result = await fetch('/api/' + path, options);
  const data = await result.json();
  if (!result.ok) throw new Error(data.error || 'درخواست انجام نشد.');
  return data;
}
function updateCart() {
  badge.textContent = num(Object.values(cart).reduce((sum, count) => sum + count, 0));
  try { localStorage.setItem('sepas.online.cart', JSON.stringify({ items: cart, key: orderKey })); } catch {}
}
function searchKey(text) { return String(text).trim().toLowerCase().replace(/ي/g, 'ی').replace(/ك/g, 'ک'); }
function photo(product) {
  return '<span class="photo">' + (product.has_photo
    ? '<img loading="lazy" src="/media/' + product.id + '" alt="' + esc(product.name) + '">'
    : '<span class="photo-mark" aria-hidden="true">✦</span>') + '</span>';
}
function price(product) {
  const compared = product.sale_price !== null;
  const off = compared ? Math.floor((product.price - product.sale_price) * 100 / product.price) : 0;
  return '<span class="price">' + money(validPrice(product)) + (compared
    ? '<del>' + num(product.price) + '</del>' + (off ? '<span class="discount">' + num(off) + '٪ تخفیف</span>' : '') : '') + '</span>';
}
function cards(rows) {
  if (!rows.length) return empty(catalog.length ? 'کالایی با این مشخصات پیدا نشد.' : 'هنوز محصولی منتشر نشده است.');
  return rows.map(product =>
    '<article class="card"><button type="button" class="photo-button" data-action="product" data-key="' + product.id +
    '" aria-label="' + esc(product.name) + '">' + photo(product) + '</button><div class="card-content"><small class="muted">' +
    esc(product.category) + '</small><h3>' + button('product', esc(product.name), product.id, 'link') + '</h3>' +
    price(product) + button('add', product.stock ? 'افزودن به سبد' : 'ناموجود', product.id, 'card-buy', !product.stock) + '</div></article>'
  ).join('');
}
function selectedProducts() {
  const results = catalog.filter(product => (!category || product.category === category) &&
    searchKey(product.name + ' ' + product.category).includes(searchKey(query)));
  if (sort === 'low') results.sort((a, b) => validPrice(a) - validPrice(b));
  if (sort === 'high') results.sort((a, b) => validPrice(b) - validPrice(a));
  if (sort === 'discount') return results.filter(product => product.sale_price !== null);
  return results;
}
function shopView() {
  const categories = [...new Set(catalog.map(product => product.category))];
  const options = [['new','جدیدترین'],['low','ارزان‌ترین'],['high','گران‌ترین'],['discount','تخفیف‌دار']];
  return '<section class="hero"><div><h1>فروشگاه سپاس</h1><p>محصولات رو ببین و خریدت رو شروع کن.</p></div></section>' +
    '<div class="toolbar"><h2>محصولات</h2></div><div class="toolbar"><input class="search" type="search" id="search" aria-label="جست‌وجوی محصول" placeholder="جست‌وجوی محصول" value="' + esc(query) +
    '"><label>مرتب‌سازی <select id="sort">' + options.map(([key, label]) =>
      '<option value="' + key + '"' + (key === sort ? ' selected' : '') + '>' + label + '</option>').join('') + '</select></label></div>' +
    '<div class="chips">' + ['', ...categories].map(name => '<button type="button" class="chip" data-action="category" data-key="' +
    esc(name) + '" aria-pressed="' + (category === name) + '">' + esc(name || 'همه') + '</button>').join('') +
    '</div><section class="product-grid" id="products">' + cards(selectedProducts()) + '</section>';
}
function productView() {
  const product = catalog.find(item => item.id === activeProduct);
  if (!product) return heading('محصول') + empty('این محصول در دسترس نیست.');
  const related = catalog.filter(item => item.id !== product.id && item.category === product.category).slice(0, 4);
  return heading(esc(product.name), button('shop', 'بازگشت به فروشگاه')) + '<section class="detail">' +
    photo(product) + '<div class="surface"><small class="muted">' + esc(product.category) + '</small>' + price(product) +
    '<p class="muted">' + (product.stock ? 'موجود' : 'ناموجود') + '</p><div class="inline-number">' +
    button('quantity', '−', -1, 'secondary', quantity <= 1) + '<strong>' + num(quantity) + '</strong>' +
    button('quantity', '+', 1, 'secondary', quantity >= Math.min(100, product.stock)) + '</div>' +
    button('add-detail', 'افزودن به سبد خرید', product.id, 'primary', !product.stock) +
    (product.description ? '<p class="muted">' + esc(product.description) + '</p>' : '') + '</div></section>' +
    (related.length ? '<div class="page-heading"><h2>محصولات مشابه</h2></div><div class="product-grid">' + cards(related) + '</div>' : '');
}
function cartView() {
  const selected = Object.entries(cart).map(([id, count]) => [catalog.find(product => product.id === Number(id)), count, id]);
  if (!selected.length) return heading('سبد خرید') + empty('سبد خرید خالیه.');
  const invalid = selected.some(([product, count]) => !product || product.stock < count);
  const total = selected.reduce((sum, [product, count]) => sum + (product ? validPrice(product) * count : 0), 0);
  return heading('سبد خرید') + '<div class="surface stack">' + selected.map(([product, count, id]) =>
    '<div class="line"><div><strong>' + esc(product?.name || 'محصول خارج از ویترین') + '</strong><p class="muted">' +
      (product && product.stock >= count ? money(validPrice(product)) : 'موجودی کافی نیست') +
      '</p></div><div class="inline-number">' + button('cart-subtract', '−', id) + '<b>' + num(count) + '</b>' +
      button('cart-add', '+', id, 'secondary', !product || count >= Math.min(100, product.stock)) +
      button('remove', 'حذف', id, 'link') + '</div></div>').join('') + '<div class="line"><strong>جمع کالاها</strong><b>' + money(total) +
    '</b></div>' + (invalid ? '<p class="error">تعداد یا کالاهای ناموجود را اصلاح کنید.</p>' :
      user?.role === 'customer' ? '<form data-form="order"><label>نشانی تحویل<textarea name="address" required maxlength="400"></textarea></label>' +
        '<p class="muted">ثبت سفارش بدون پرداخت در اپ. هماهنگی پرداخت با فروشنده است.</p>' + formError() +
        '<button class="primary" type="submit">ثبت سفارش</button></form>' : button('checkout-login', 'ورود برای ثبت سفارش', '', 'primary')) + '</div>';
}
function loginView(role, register = false) {
  const seller = role === 'seller';
  const title = seller ? 'ورود فروشنده' : register ? 'ساخت حساب مشتری' : 'ورود مشتری';
  return heading(title) + '<form class="surface stack" data-form="' +
    (register ? 'register' : seller ? 'seller-login' : 'customer-login') + '">' + (register
    ? field('نام و نام خانوادگی', 'name', '', 'required maxlength="90" autocomplete="name"') +
      field('موبایل', 'phone', '', 'required inputmode="tel" autocomplete="tel"') +
      field('نام کاربری (اختیاری)', 'username', '', 'maxlength="30" autocomplete="username"')
    : field(seller ? 'نام کاربری، ایمیل یا موبایل' : 'موبایل یا نام کاربری', 'identity', '', 'required autocomplete="username"')) +
    field('رمز عبور', 'password', '', 'required type="password" minlength="8" maxlength="128" autocomplete="' +
      (register ? 'new-password' : 'current-password') + '"') + formError() +
    '<button class="primary" type="submit">' + (register ? 'ثبت‌نام' : 'ورود') + '</button>' +
    (seller ? '' : button(register ? 'account' : 'register', register ? 'رفتن به ورود' : 'ساخت حساب مشتری')) + '</form>';
}
function orderCard(order, seller) {
  const next = seller ? order.next || [] : [];
  return '<article class="order"><div class="line"><strong dir="ltr">' + esc(order.code) + '</strong><span class="state">' +
    states[order.status] + '</span></div><p class="muted">' + dates.format(new Date(order.created_at)) + '</p>' +
    (seller ? '<p class="muted">' + esc(order.name) + ' · ' + esc(order.phone) + '<br>' + esc(order.address) + '</p>' : '') +
    order.items.map(item => '<div class="line"><span>' + esc(item.name) + ' × ' + num(item.quantity) + '</span><small>' + money(item.unit_price) + '</small></div>').join('') +
    '<div class="line"><strong>جمع سفارش</strong><b>' + money(order.total) + '</b></div>' +
    (next.length ? '<form data-form="status" data-key="' + order.id + '"><label>تغییر وضعیت<select name="status">' +
      next.map(status => '<option value="' + status + '">' + states[status] + '</option>').join('') +
      '</select></label>' + formError() + '<button class="secondary" type="submit">ذخیره وضعیت</button></form>' : '') + '</article>';
}
function accountView() {
  return user?.role === 'customer' ? heading('سفارش‌های من', button('logout', 'خروج')) +
    '<div class="stack">' + (orders.length ? orders.map(order => orderCard(order, false)).join('') : empty('هنوز سفارشی ثبت نکردی.')) +
    '</div>' : loginView('customer');
}
function sellerView(showOrders) {
  return heading(showOrders ? 'سفارش‌های فروشگاه' : 'محصولات فروشگاه', button('logout', 'خروج از حساب فروشنده')) +
    '<div class="actions seller-top">' + button('seller-products', 'محصولات') + button('seller-orders', 'سفارش‌ها') +
    (showOrders ? '' : button('seller-edit', 'افزودن محصول', '', 'primary')) + '</div><br><div class="stack">' +
    (showOrders ? (orders.length ? orders.map(order => orderCard(order, true)).join('') : empty('هنوز سفارشی ثبت نشده است.')) :
      (sellerProducts.length ? sellerProducts.map(product => '<div class="surface line"><div><strong>' + esc(product.name) +
        '</strong><p class="muted">' + (product.active ? 'منتشرشده' : 'پنهان از ویترین') + ' · موجودی ' +
        num(product.stock) + ' · ' + money(validPrice(product)) + '</p></div>' + button('seller-edit', 'ویرایش', product.id) + '</div>').join('') :
        empty('اولین محصول فروشگاهت رو اضافه کن.'))) + '</div>';
}
function sellerEdit(id) {
  const product = sellerProducts.find(item => item.id === id);
  return heading(product ? 'ویرایش محصول' : 'افزودن محصول', button('seller-products', 'بازگشت')) +
    '<form class="surface stack" data-form="product" data-key="' + (product?.id ?? '') + '">' +
    field('نام محصول', 'name', product?.name, 'required maxlength="100"') +
    field('دسته‌بندی', 'category', product?.category, 'required maxlength="80"') +
    '<label>توضیحات<textarea name="description" maxlength="2000">' + esc(product?.description) + '</textarea></label><div class="columns">' +
    field('قیمت (تومان)', 'price', product?.price, 'required inputmode="numeric"') +
    field('قیمت با تخفیف (اختیاری)', 'sale_price', product?.sale_price, 'inputmode="numeric"') +
    '</div>' + field('موجودی', 'stock', product?.stock ?? 0, 'required inputmode="numeric"') +
    (product?.has_photo ? photo(product) + '<label class="check"><input type="checkbox" name="remove_photo">حذف عکس فعلی</label>' : '') +
    '<label>عکس محصول، تا ۲ مگابایت<input type="file" name="photo" accept="image/jpeg,image/png,image/webp"></label>' +
    '<label class="check"><input type="checkbox" name="active"' + (!product || product.active ? ' checked' : '') +
    '>نمایش در ویترین</label>' + formError() + '<button class="primary" type="submit">ذخیره محصول</button></form>';
}
function render() {
  const views = {
    shop: shopView, product: productView, cart: cartView, account: accountView,
    register: () => loginView('customer', true), 'seller-login': () => loginView('seller'),
    'seller-products': () => sellerView(false), 'seller-orders': () => sellerView(true),
    'seller-edit': () => sellerEdit(activeProduct)
  };
  main.innerHTML = views[screen]();
  updateCart();
}
function go(view) { screen = view; render(); window.scrollTo(0, 0); }
async function loadCatalog() { catalog = await api('catalog'); }
async function openAccount() {
  if (user?.role === 'customer') orders = await api('orders');
  go('account');
}
async function openSeller(view) {
  if (user?.role !== 'seller') return go('seller-login');
  if (view === 'seller-orders') orders = await api('seller/orders');
  else sellerProducts = await api('seller/products');
  go(view);
}
function setQuantity(id, difference) {
  const stock = catalog.find(product => product.id === id)?.stock ?? 0;
  const count = (cart[id] ?? 0) + difference;
  if (difference > 0 && count > Math.min(stock, 100)) return false;
  if (count <= 0) delete cart[id];
  else cart[id] = count;
  orderKey = '';
  updateCart();
  return true;
}
function asNumber(value) {
  const digits = value.trim().replace(/[۰-۹]/g, c => '۰۱۲۳۴۵۶۷۸۹'.indexOf(c))
    .replace(/[٠-٩]/g, c => '٠١٢٣٤٥٦٧٨٩'.indexOf(c)).replace(/[٬,]/g, '');
  if (!/^\d+$/.test(digits)) throw new Error('قیمت و موجودی باید عدد صحیح باشند.');
  return Number(digits);
}
async function imageData(file) {
  if (!file?.size) return null;
  if (file.size > 2_000_000) throw new Error('عکس محصول حداکثر ۲ مگابایت باشد.');
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error('عکس خوانده نشد.'));
    reader.readAsDataURL(file);
  });
}
const actions = {
  shop: async () => { await loadCatalog(); go('shop'); },
  product: id => { activeProduct = +id; quantity = 1; go('product'); },
  account: () => { afterLogin = 'account'; return openAccount(); },
  register: () => go('register'),
  'checkout-login': () => { afterLogin = 'cart'; go('account'); },
  cart: async () => { await loadCatalog(); go('cart'); },
  category: value => { category = value; render(); },
  quantity: delta => { quantity += +delta; render(); },
  add: id => notice(setQuantity(+id, 1) ? 'به سبد اضافه شد.' : 'موجودی کافی نیست.'),
  'add-detail': id => notice(setQuantity(+id, quantity) ? 'به سبد اضافه شد.' : 'موجودی کافی نیست.'),
  'cart-add': id => { setQuantity(+id, 1); render(); },
  'cart-subtract': id => { setQuantity(+id, -1); render(); },
  remove: id => { delete cart[id]; orderKey = ''; render(); },
  'seller-products': () => openSeller('seller-products'),
  'seller-orders': () => openSeller('seller-orders'),
  'seller-edit': id => { if (user?.role === 'seller') { activeProduct = +id; go('seller-edit'); } },
  logout: async () => {
    await api('logout', {});
    user = null;
    orders = [];
    sellerProducts = [];
    await loadCatalog();
    go('shop');
  }
};

document.querySelector('#brand').addEventListener('click', async () => {
  const now = Date.now();
  taps = now - lastTap <= 900 ? taps + 1 : 1;
  lastTap = now;
  try {
    if (taps >= 5) {
      taps = 0;
      await openSeller('seller-products');
    } else if (taps === 1 && screen !== 'shop') {
      go('shop');
    }
  } catch (error) { notice(error.message); }
});
document.addEventListener('click', async event => {
  const control = event.target.closest('button[data-action]');
  if (!control || control.disabled) return;
  try { await actions[control.dataset.action](control.dataset.key); }
  catch (error) { notice(error.message); }
});
document.addEventListener('input', event => {
  if (event.target.id !== 'search') return;
  query = event.target.value;
  document.querySelector('#products').innerHTML = cards(selectedProducts());
});
document.addEventListener('change', event => {
  if (event.target.id !== 'sort') return;
  sort = event.target.value;
  document.querySelector('#products').innerHTML = cards(selectedProducts());
});

const formActions = {
  register: async form => {
    await api('register', Object.fromEntries(form));
    user = await api('session');
    if (afterLogin === 'cart') go('cart');
    else await openAccount();
  },
  'customer-login': async form => {
    await api('customer/login', Object.fromEntries(form));
    user = await api('session');
    if (afterLogin === 'cart') go('cart');
    else await openAccount();
  },
  'seller-login': async form => {
    await api('seller/login', Object.fromEntries(form));
    user = await api('session');
    await openSeller('seller-products');
  },
  product: async (form, id) => {
    const product = sellerProducts.find(item => item.id === +id);
    await api('seller/products', {
      id: product?.id ?? null, original_stock: product?.stock, name: form.get('name'), category: form.get('category'),
      description: form.get('description'), price: asNumber(form.get('price')), stock: asNumber(form.get('stock')),
      sale_price: form.get('sale_price').trim() ? asNumber(form.get('sale_price')) : null,
      active: form.has('active'), remove_photo: form.has('remove_photo'), photo: await imageData(form.get('photo'))
    });
    await loadCatalog();
    await openSeller('seller-products');
    notice('محصول ذخیره شد.');
  },
  order: async form => {
    if (!orderKey) orderKey = crypto.randomUUID();
    updateCart();
    const items = Object.entries(cart).map(([id, count]) => {
      const product = catalog.find(item => item.id === +id);
      return { id: +id, quantity: count, unit_price: product ? validPrice(product) : null };
    });
    const result = await api('orders', { key: orderKey, address: form.get('address'), items });
    cart = {};
    orderKey = '';
    updateCart();
    await loadCatalog();
    await openAccount();
    notice('سفارش ثبت شد · ' + result.code);
  },
  status: async (form, id) => {
    await api('seller/orders', { id: +id, status: form.get('status') });
    await loadCatalog();
    await openSeller('seller-orders');
    notice('وضعیت سفارش ذخیره شد.');
  }
};

document.addEventListener('submit', async event => {
  const form = event.target;
  const handler = formActions[form.dataset.form];
  if (!handler) return;
  event.preventDefault();
  const submit = form.querySelector('button[type="submit"]');
  if (submit.disabled) return;
  submit.disabled = true;
  const errorBox = form.querySelector('.error');
  errorBox.textContent = '';
  try { await handler(new FormData(form), form.dataset.key); }
  catch (error) { errorBox.textContent = error.message; }
  finally { submit.disabled = false; }
});

window.sepasBack = () => {
  if (screen === 'shop') return false;
  if (screen === 'seller-edit' || screen === 'seller-orders') {
    openSeller('seller-products').catch(error => notice(error.message));
  } else if (screen === 'register') go('account');
  else go('shop');
  return true;
};

Promise.all([api('session'), loadCatalog()]).then(([session]) => {
  user = session;
  go('shop');
}).catch(() => {
  main.innerHTML = empty('اتصال به فروشگاه برقرار نشد.') + '<div class="actions">' + button('shop', 'تلاش دوباره') + '</div>';
});
