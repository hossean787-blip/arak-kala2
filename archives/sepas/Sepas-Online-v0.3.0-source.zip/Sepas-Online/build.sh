#!/usr/bin/env bash
set -euo pipefail

app_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
src="$app_dir/app/src/main"
tools="${ANDROID_HOME:?Set ANDROID_HOME}/build-tools/36.0.0"
android_jar="$ANDROID_HOME/platforms/android-36/android.jar"
jdk="${JAVA_HOME:?Set JAVA_HOME}/bin"
output="${1:-$app_dir/Sepas-unsigned.apk}"
build="$(mktemp -d)"
trap 'rm -rf "$build"' EXIT
mkdir -p "$build/classes" "$build/dex"

"$tools/aapt2" compile --dir "$src/res" -o "$build/resources.zip"
"$tools/aapt2" link -I "$android_jar" --manifest "$src/AndroidManifest.xml" \
  -o "$build/base.apk" "$build/resources.zip"
"$jdk/javac" --release 8 -encoding UTF-8 -classpath "$android_jar" -d "$build/classes" \
  "$src/java/ir/sepas/shop/"*.java
"$jdk/jar" cf "$build/classes.jar" -C "$build/classes" .
"$jdk/java" -cp "$tools/lib/d8.jar" com.android.tools.r8.D8 --release --min-api 24 \
  --lib "$android_jar" --output "$build/dex" "$build/classes.jar"
(cd "$build/dex" && zip -q -j "$build/base.apk" classes*.dex)
mkdir -p "$(dirname "$output")"
"$tools/zipalign" -P 16 -f 4 "$build/base.apk" "$output"
