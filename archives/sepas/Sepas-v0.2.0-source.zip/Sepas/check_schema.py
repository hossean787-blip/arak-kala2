"""Exercise the bundled database schema and the sale transaction's constraints."""

import sqlite3
from pathlib import Path
from tempfile import TemporaryDirectory

schema = Path(__file__).parent / "app/src/main/assets/schema.sql"
with TemporaryDirectory() as directory:
    path = Path(directory) / "test.db"
    connection = sqlite3.connect(path)
    connection.execute("PRAGMA foreign_keys = ON")
    connection.executescript(schema.read_text(encoding="utf-8"))
    assert connection.execute("SELECT revision, next_invoice FROM store_state").fetchone() == (0, 1)

    with connection:
        connection.execute(
            "INSERT INTO products VALUES (?, ?, ?, ?, ?, ?)",
            ("test-id", "چای", "۱۲۳", "123", 12000, 5),
        )
        connection.execute("UPDATE store_state SET revision = 1 WHERE revision = 0")

    try:
        with connection:
            connection.execute("UPDATE products SET stock = 4 WHERE id = 'test-id'")
            connection.execute(
                "INSERT INTO sale_lines VALUES (1, 0, 'چای', '۱۲۳', 12000, 1)"
            )
    except sqlite3.IntegrityError:
        pass
    else:
        raise AssertionError("A sale line cannot exist without an invoice")

    assert connection.execute("SELECT stock FROM products").fetchone() == (5,)
    with connection:
        connection.execute(
            "INSERT INTO sales VALUES (1, '2026-11-23T15:00:00Z', '', 'نقدی', 1000, 23000)"
        )
        connection.execute("INSERT INTO sale_lines VALUES (1, 0, 'چای', '۱۲۳', 12000, 2)")
        assert connection.execute(
            "UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?",
            (2, "test-id", 2),
        ).rowcount == 1
        connection.execute("UPDATE store_state SET next_invoice = 2, revision = 2 WHERE revision = 1")

    connection.close()
    with sqlite3.connect(path) as reopened:
        reopened.execute("PRAGMA foreign_keys = ON")
        assert reopened.execute("SELECT stock FROM products").fetchone() == (3,)
        assert reopened.execute("SELECT total FROM sales").fetchone() == (23000,)
        assert reopened.execute("SELECT revision, next_invoice FROM store_state").fetchone() == (2, 2)
        assert reopened.execute(
            "UPDATE store_state SET revision = 2 WHERE revision = 1"
        ).rowcount == 0
        reopened.execute("DELETE FROM products WHERE id = 'test-id'")
        assert reopened.execute("SELECT name, price, quantity FROM sale_lines").fetchone() == ("چای", 12000, 2)
        reopened.execute("DELETE FROM sales WHERE number = 1")
        assert reopened.execute("SELECT count(*) FROM sale_lines").fetchone() == (0,)

print("PASS: real SQLite schema, foreign keys, transaction rollback, stale revision, persistence, and historical receipts.")
