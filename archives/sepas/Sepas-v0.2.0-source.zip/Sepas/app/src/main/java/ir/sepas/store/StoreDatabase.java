package ir.sepas.store;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

final class StoreDatabase extends SQLiteOpenHelper {
    private static final long MAX_TOTAL = 999_999_999_999L;
    static final long CONFLICT = -2;
    private final Context context;

    StoreDatabase(Context context) {
        super(context, "sepas.db", null, 1);
        this.context = context.getApplicationContext();
    }

    @Override public void onConfigure(SQLiteDatabase db) {
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                context.getAssets().open("schema.sql"), StandardCharsets.UTF_8))) {
            StringBuilder statement = new StringBuilder();
            for (String line; (line = reader.readLine()) != null; ) {
                statement.append(line).append('\n');
                if (line.trim().endsWith(";")) {
                    db.execSQL(statement.toString());
                    statement.setLength(0);
                }
            }
            if (statement.length() != 0) throw new SQLiteException("Incomplete Sepas schema");
        } catch (IOException error) {
            throw new SQLiteException("Cannot read Sepas schema", error);
        }
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        throw new SQLiteException("Unsupported Sepas database upgrade");
    }

    JSONObject read() throws JSONException {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransactionNonExclusive();
        try (Cursor settings = db.rawQuery("SELECT revision, shop, next_invoice FROM store_state WHERE id = 1", null)) {
            if (!settings.moveToFirst()) throw new SQLiteException("Store settings missing");
            long revision = settings.getLong(0);
            JSONObject result = new JSONObject().put("revision", revision);
            if (revision == 0) {
                result.put("state", JSONObject.NULL);
            } else {
                result.put("state", new JSONObject()
                    .put("schema", 1)
                    .put("shop", settings.getString(1))
                    .put("nextInvoice", settings.getInt(2))
                    .put("products", readProducts(db))
                    .put("sales", readSales(db)));
            }
            db.setTransactionSuccessful();
            return result;
        } finally {
            db.endTransaction();
        }
    }

    private JSONArray readProducts(SQLiteDatabase db) throws JSONException {
        JSONArray products = new JSONArray();
        try (Cursor rows = db.rawQuery("SELECT id, name, sku, price, stock FROM products ORDER BY rowid", null)) {
            while (rows.moveToNext()) {
                products.put(new JSONObject()
                    .put("id", rows.getString(0)).put("name", rows.getString(1))
                    .put("sku", rows.getString(2)).put("price", rows.getLong(3))
                    .put("stock", rows.getInt(4)));
            }
        }
        return products;
    }

    private JSONArray readSales(SQLiteDatabase db) throws JSONException {
        JSONArray sales = new JSONArray();
        String query = "SELECT s.number, s.issued_at, s.customer, s.payment, s.discount, s.total,"
            + " l.name, l.sku, l.price, l.quantity FROM sales s JOIN sale_lines l ON l.sale_number = s.number"
            + " ORDER BY s.number, l.position";
        try (Cursor rows = db.rawQuery(query, null)) {
            int lastNumber = 0;
            JSONArray lines = null;
            while (rows.moveToNext()) {
                int number = rows.getInt(0);
                if (number != lastNumber) {
                    lastNumber = number;
                    lines = new JSONArray();
                    sales.put(new JSONObject()
                        .put("number", number).put("date", rows.getString(1))
                        .put("customer", rows.getString(2)).put("payment", rows.getString(3))
                        .put("discount", rows.getLong(4)).put("total", rows.getLong(5))
                        .put("items", lines));
                }
                lines.put(new JSONObject().put("name", rows.getString(6))
                    .put("sku", rows.getString(7)).put("price", rows.getLong(8))
                    .put("quantity", rows.getInt(9)));
            }
        }
        return sales;
    }

    long write(long revision, String payload) throws JSONException {
        JSONObject change = new JSONObject(payload);
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransactionNonExclusive();
        try {
            if (advanceRevision(db, revision) == 0) return CONFLICT;
            switch (change.getString("kind")) {
                case "replace":
                    replace(db, change.getJSONObject("state"));
                    break;
                case "product":
                    writeProduct(db, change.getJSONObject("product"), change.getBoolean("existing"));
                    break;
                case "deleteProduct":
                    if (db.delete("products", "id = ?", new String[] { change.getString("id") }) != 1) {
                        throw new SQLiteException("Product no longer exists");
                    }
                    break;
                case "sale":
                    JSONObject sale = change.getJSONObject("sale");
                    recordSale(db, sale);
                    break;
                case "settings":
                    ContentValues settings = new ContentValues();
                    settings.put("shop", change.getString("shop"));
                    db.update("store_state", settings, "id = 1", null);
                    break;
                default:
                    throw new JSONException("Unknown Sepas transaction");
            }
            db.setTransactionSuccessful();
            return revision + 1;
        } finally {
            db.endTransaction();
        }
    }

    private int advanceRevision(SQLiteDatabase db, long expected) {
        ContentValues revision = new ContentValues();
        revision.put("revision", expected + 1);
        return db.update("store_state", revision, "id = 1 AND revision = ?",
            new String[] { Long.toString(expected) });
    }

    private void replace(SQLiteDatabase db, JSONObject state) throws JSONException {
        if (state.getInt("schema") != 1) throw new JSONException("Unsupported Sepas backup");
        db.delete("sales", null, null);
        db.delete("products", null, null);
        JSONArray products = state.getJSONArray("products");
        for (int i = 0; i < products.length(); i++) {
            writeProduct(db, products.getJSONObject(i), false);
        }
        int nextInvoice = state.getInt("nextInvoice");
        JSONArray sales = state.getJSONArray("sales");
        for (int i = 0; i < sales.length(); i++) {
            JSONObject sale = sales.getJSONObject(i);
            if (sale.getInt("number") >= nextInvoice) throw new JSONException("Invalid invoice sequence");
            insertSale(db, sale);
        }
        ContentValues settings = new ContentValues();
        settings.put("shop", state.getString("shop"));
        settings.put("next_invoice", nextInvoice);
        db.update("store_state", settings, "id = 1", null);
    }

    private void writeProduct(SQLiteDatabase db, JSONObject product, boolean existing) throws JSONException {
        String id = product.getString("id");
        ContentValues values = new ContentValues();
        values.put("name", product.getString("name"));
        values.put("sku", product.getString("sku"));
        values.put("sku_key", product.getString("skuKey"));
        values.put("price", product.getLong("price"));
        values.put("stock", product.getInt("stock"));
        if (existing) {
            if (db.update("products", values, "id = ?", new String[] { id }) != 1) {
                throw new SQLiteException("Product no longer exists");
            }
        } else {
            values.put("id", id);
            db.insertOrThrow("products", null, values);
        }
    }

    private void recordSale(SQLiteDatabase db, JSONObject sale) throws JSONException {
        int number = sale.getInt("number");
        ContentValues settings = new ContentValues();
        settings.put("next_invoice", number + 1);
        if (db.update("store_state", settings, "id = 1 AND next_invoice = ?",
                new String[] { Integer.toString(number) }) != 1) {
            throw new SQLiteException("Invoice sequence changed");
        }
        insertSale(db, sale);
        JSONArray lines = sale.getJSONArray("items");
        for (int i = 0; i < lines.length(); i++) {
            JSONObject line = lines.getJSONObject(i);
            int quantity = line.getInt("quantity");
            try (android.database.sqlite.SQLiteStatement statement = db.compileStatement(
                    "UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?"
                    + " AND name = ? AND sku = ? AND price = ?")) {
                statement.bindLong(1, quantity);
                statement.bindString(2, line.getString("productId"));
                statement.bindLong(3, quantity);
                statement.bindString(4, line.getString("name"));
                statement.bindString(5, line.getString("sku"));
                statement.bindLong(6, line.getLong("price"));
                if (statement.executeUpdateDelete() != 1) {
                    throw new SQLiteException("Sale line no longer matches inventory");
                }
            }
        }
    }

    private void insertSale(SQLiteDatabase db, JSONObject sale) throws JSONException {
        int number = sale.getInt("number");
        long discount = sale.getLong("discount");
        long total = sale.getLong("total");
        JSONArray lines = sale.getJSONArray("items");
        if (lines.length() == 0) throw new JSONException("Invoice has no lines");
        ContentValues values = new ContentValues();
        values.put("number", number);
        values.put("issued_at", sale.getString("date"));
        values.put("customer", sale.getString("customer"));
        values.put("payment", sale.getString("payment"));
        values.put("discount", discount);
        values.put("total", total);
        db.insertOrThrow("sales", null, values);

        long subtotal = 0;
        for (int i = 0; i < lines.length(); i++) {
            JSONObject line = lines.getJSONObject(i);
            long price = line.getLong("price");
            int quantity = line.getInt("quantity");
            ContentValues item = new ContentValues();
            item.put("sale_number", number);
            item.put("position", i);
            item.put("name", line.getString("name"));
            item.put("sku", line.getString("sku"));
            item.put("price", price);
            item.put("quantity", quantity);
            db.insertOrThrow("sale_lines", null, item);
            subtotal += price * quantity;
            if (subtotal > MAX_TOTAL) throw new JSONException("Invoice subtotal exceeds the supported limit");
        }
        if (subtotal - discount != total) throw new JSONException("Invalid invoice total");
    }
}
