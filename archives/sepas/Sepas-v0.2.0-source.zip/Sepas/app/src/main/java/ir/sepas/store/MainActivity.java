package ir.sepas.store;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.database.sqlite.SQLiteException;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.util.Base64;
import android.util.Log;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONException;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Collections;

public final class MainActivity extends Activity {
    private static final int PICK_BACKUP = 1;
    private static final int SAVE_BACKUP = 2;
    private static final String APP_HOST = "sepas.local";
    private WebView webView;
    private StoreDatabase database;
    private static final int MAX_BACKUP_BYTES = 5_000_000;
    private File backupDraft;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(18, 51, 49));
        getWindow().setNavigationBarColor(Color.rgb(18, 51, 49));
        backupDraft = new File(getCacheDir(), "backup-draft.json");
        if (savedInstanceState == null) backupDraft.delete();

        database = new StoreDatabase(this);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(244, 246, 241));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setBlockNetworkLoads(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.addJavascriptInterface(new StoreBridge(), "SepasAndroid");

        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !isAppOrigin(request.getUrl());
            }

            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();
                if (isAppOrigin(url)) {
                    switch (url.getPath()) {
                        case "/index.html": return asset("index.html", "text/html");
                        case "/app.css": return asset("app.css", "text/css");
                        case "/app.js": return asset("app.js", "application/javascript");
                        case "/font-regular.ttf": return asset("font-regular.ttf", "font/ttf");
                        case "/font-bold.ttf": return asset("font-bold.ttf", "font/ttf");
                    }
                }
                return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found",
                    Collections.emptyMap(), new ByteArrayInputStream(new byte[0]));
            }
        });

        webView.setWebChromeClient(new WebChromeClient());

        setContentView(webView);
        webView.loadUrl("https://" + APP_HOST + "/index.html");
    }

    private boolean isAppOrigin(Uri uri) {
        return "https".equals(uri.getScheme()) && APP_HOST.equals(uri.getHost()) && uri.getPort() == -1;
    }

    private WebResourceResponse asset(String name, String mime) {
        try {
            return new WebResourceResponse(mime, "UTF-8", getAssets().open(name));
        } catch (IOException error) {
            return null;
        }
    }

    @Override public void onBackPressed() {
        webView.evaluateJavascript("window.sepasBack && window.sepasBack()", result -> {
            if (!"true".equals(result)) {
                super.onBackPressed();
            }
        });
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        Uri uri = result == RESULT_OK && data != null ? data.getData() : null;
        if (request == PICK_BACKUP && uri != null) readBackup(uri);
        if (request == SAVE_BACKUP) {
            if (uri != null) writeBackup(uri);
            else backupDraft.delete();
        }
    }

    private void readBackup(Uri uri) {
        new Thread(() -> {
            try (InputStream input = getContentResolver().openInputStream(uri);
                 ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
                if (input == null) throw new IOException("Cannot read backup");
                byte[] chunk = new byte[8192];
                for (int length; (length = input.read(chunk)) != -1; ) {
                    if (buffer.size() + length > MAX_BACKUP_BYTES) throw new IOException("Backup is too large");
                    buffer.write(chunk, 0, length);
                }
                String data = Base64.encodeToString(buffer.toByteArray(), Base64.NO_WRAP);
                runOnUiThread(() -> webView.evaluateJavascript("window.sepasRestoreBase64('" + data + "')", null));
            } catch (IOException | SecurityException error) {
                runOnUiThread(() -> notifyUser("خواندن فایل پشتیبان ممکن نبود"));
            }
        }).start();
    }

    private void writeBackup(Uri uri) {
        new Thread(() -> {
            try (InputStream input = new FileInputStream(backupDraft);
                 OutputStream stream = getContentResolver().openOutputStream(uri, "wt")) {
                if (stream == null) throw new IOException("Cannot open backup");
                byte[] chunk = new byte[8192];
                for (int length; (length = input.read(chunk)) != -1; ) stream.write(chunk, 0, length);
                runOnUiThread(() -> notifyUser("پشتیبان ذخیره شد"));
            } catch (IOException | SecurityException error) {
                runOnUiThread(() -> notifyUser("پشتیبان ذخیره نشد"));
            } finally {
                backupDraft.delete();
            }
        }).start();
    }

    private void notifyUser(String text) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
    }

    @Override protected void onDestroy() {
        webView.destroy();
        database.close();
        super.onDestroy();
    }

    private final class StoreBridge {
        @JavascriptInterface public String readStore() {
            try {
                return database.read().toString();
            } catch (SQLiteException | JSONException error) {
                Log.e("SepasStore", "Could not read local storage");
                return null;
            }
        }

        @JavascriptInterface public long writeStore(long revision, String payload) {
            if (revision < 0 || payload == null) return -1;
            try {
                return database.write(revision, payload);
            } catch (SQLiteException | JSONException error) {
                Log.e("SepasStore", "Local transaction failed");
                return -1;
            }
        }

        @JavascriptInterface public void saveBackup(String data) {
            runOnUiThread(() -> {
                byte[] bytes = data == null ? new byte[0] : data.getBytes(StandardCharsets.UTF_8);
                if (backupDraft.exists() || bytes.length == 0 || bytes.length > MAX_BACKUP_BYTES) {
                    notifyUser("امکان ذخیرهٔ این پشتیبان وجود ندارد");
                    return;
                }
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, "Sepas-backup.json");
                try {
                    try (OutputStream draft = new FileOutputStream(backupDraft)) {
                        draft.write(bytes);
                    }
                    startActivityForResult(intent, SAVE_BACKUP);
                } catch (ActivityNotFoundException | IOException error) {
                    backupDraft.delete();
                    notifyUser("انتخاب محل ذخیره در دسترس نیست");
                }
            });
        }

        @JavascriptInterface public void pickBackup() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                try {
                    startActivityForResult(intent, PICK_BACKUP);
                } catch (ActivityNotFoundException error) {
                    notifyUser("انتخاب فایل در دسترس نیست");
                }
            });
        }

        @JavascriptInterface public void shareReceipt(String text) {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_TEXT, text);
                startActivity(Intent.createChooser(intent, "اشتراک رسید"));
            });
        }
    }
}
