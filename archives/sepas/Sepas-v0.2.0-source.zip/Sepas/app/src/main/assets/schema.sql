CREATE TABLE store_state (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  revision INTEGER NOT NULL CHECK (revision >= 0),
  shop TEXT NOT NULL CHECK (length(shop) BETWEEN 1 AND 60),
  next_invoice INTEGER NOT NULL CHECK (next_invoice BETWEEN 1 AND 1000000)
);
INSERT INTO store_state (id, revision, shop, next_invoice) VALUES (1, 0, 'سپاس', 1);
CREATE TABLE products (
  id TEXT NOT NULL PRIMARY KEY CHECK (length(id) BETWEEN 1 AND 80),
  name TEXT NOT NULL CHECK (length(name) BETWEEN 1 AND 100),
  sku TEXT NOT NULL CHECK (length(sku) BETWEEN 1 AND 50),
  sku_key TEXT NOT NULL UNIQUE,
  price INTEGER NOT NULL CHECK (price BETWEEN 0 AND 999999999),
  stock INTEGER NOT NULL CHECK (stock BETWEEN 0 AND 100000)
);
CREATE TABLE sales (
  number INTEGER PRIMARY KEY CHECK (number BETWEEN 1 AND 999999),
  issued_at TEXT NOT NULL CHECK (length(issued_at) BETWEEN 1 AND 40),
  customer TEXT NOT NULL CHECK (length(customer) <= 80),
  payment TEXT NOT NULL CHECK (payment IN ('کارت‌خوان', 'نقدی', 'انتقال بانکی')),
  discount INTEGER NOT NULL CHECK (discount BETWEEN 0 AND 999999999999),
  total INTEGER NOT NULL CHECK (total BETWEEN 0 AND 999999999999)
);
CREATE TABLE sale_lines (
  sale_number INTEGER NOT NULL REFERENCES sales(number) ON DELETE CASCADE,
  position INTEGER NOT NULL CHECK (position >= 0),
  name TEXT NOT NULL CHECK (length(name) BETWEEN 1 AND 100),
  sku TEXT NOT NULL CHECK (length(sku) BETWEEN 1 AND 50),
  price INTEGER NOT NULL CHECK (price BETWEEN 0 AND 999999999),
  quantity INTEGER NOT NULL CHECK (quantity BETWEEN 1 AND 100000),
  PRIMARY KEY (sale_number, position)
);
