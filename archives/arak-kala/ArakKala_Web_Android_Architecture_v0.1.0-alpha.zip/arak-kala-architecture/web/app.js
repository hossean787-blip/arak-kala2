'use strict';
const $ = (s) => document.querySelector(s);
const state = { products:[], cart:[], token: sessionStorage.getItem('arak_token')||'', user:null, category:'', search:'' };
const fa = (n) => Number(n||0).toLocaleString('fa-IR');
const toman = (n) => `${fa(n)} تومان`;
const escapeHtml = (s) => String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let toastTimeout;
function toast(message){ const t=$('#toast');t.textContent=message;t.hidden=false;clearTimeout(toastTimeout);toastTimeout=setTimeout(()=>t.hidden=true,3400); }
async function api(path, options={}) {
  const {body, ...other}=options;
  const headers={'Content-Type':'application/json',...(state.token?{'Authorization':`Bearer ${state.token}`}:{})};
  let response;
  try{response=await fetch(`/api${path}`,{...other,headers,body:body==null?undefined:JSON.stringify(body)});}catch{throw new Error('اتصال به سرور برقرار نشد')}
  const data=await response.json().catch(()=>({}));
  if(!response.ok)throw new Error(data.error||'خطای غیرمنتظره');
  return data;
}
function loadCart(){try{state.cart=JSON.parse(localStorage.getItem('arak_cart')||'[]');if(!Array.isArray(state.cart))state.cart=[];}catch{state.cart=[]}}
function saveCart(){localStorage.setItem('arak_cart',JSON.stringify(state.cart));renderCartCount()}
function renderCartCount(){$('#cartCount').textContent=fa(state.cart.reduce((s,x)=>s+x.quantity,0))}
async function loadProducts(){try{
   const d=await api('/products');state.products=d.products;renderCategories();renderProducts();
 }catch(e){toast(e.message);$('#emptyTitle').textContent='بارگذاری محصولات امکان‌پذیر نیست';$('#emptyText').textContent='ارتباط با سرور را بررسی کنید.';$('#emptyState').hidden=false;}}
function renderCategories(){
  const cats=[...new Set(state.products.map(p=>p.category))];
  const root=$('#categories');root.innerHTML='<button type="button" class="chip active" data-cat="">همه محصولات</button>'+
    cats.map(c=>`<button type="button" class="chip" data-cat="${escapeHtml(c)}">${escapeHtml(c)}</button>`).join('');
  root.querySelectorAll('[data-cat]').forEach(btn=>btn.addEventListener('click',()=>{state.category=btn.dataset.cat;root.querySelectorAll('.chip').forEach(n=>n.classList.toggle('active',n===btn));renderProducts();}));
}
function picture(p,cl=''){return p.images?.length?`<img class="${cl}" src="${escapeHtml(p.images[0])}" alt="${escapeHtml(p.name)}" loading="lazy">`:`<div class="product-placeholder" aria-hidden="true">AK.</div>`}
function renderProducts(){
 const q=state.search.trim().toLocaleLowerCase('fa');
 const ps=state.products.filter(p=>(!state.category||state.category===p.category)&&(!q||p.name.toLocaleLowerCase('fa').includes(q)||p.description.toLocaleLowerCase('fa').includes(q)));
 $('#productGrid').innerHTML=ps.map(p=>`<article class="product-card"><div class="product-photo">${picture(p)}<button aria-label="نمایش ${escapeHtml(p.name)}" data-product="${p.id}">↗</button></div><div class="product-meta"><div class="product-category">${escapeHtml(p.category)}</div><div class="product-name">${escapeHtml(p.name)}</div><div class="product-price">${toman(p.price)}</div>${!p.stock?'<span class="out-of-stock">ناموجود</span>':''}</div></article>`).join('');
 $('#emptyTitle').textContent=state.products.length?'محصولی با این مشخصات پیدا نشد':'هنوز محصولی ثبت نشده';
 $('#emptyText').textContent=state.products.length?'جست‌وجو یا دسته‌بندی را تغییر دهید.':'به‌محض بارگذاری محصول از اپ مدیریت، اینجا نمایش داده می‌شود.';
 $('#emptyState').hidden=ps.length>0;
 $('#productGrid').querySelectorAll('[data-product]').forEach(btn=>btn.addEventListener('click',()=>viewProduct(Number(btn.dataset.product))));
}
function openOverlay(type){$('#overlay').hidden=false;const node=type==='drawer'?$('#drawer'):$('#modal');node.hidden=false;document.body.style.overflow='hidden'}
function closeOverlay(){$('#overlay').hidden=true;$('#drawer').hidden=true;$('#modal').hidden=true;document.body.style.overflow=''}
function cartTotal(){return state.cart.reduce((s,i)=>{const p=state.products.find(p=>p.id===i.id);return s+(p?p.price*i.quantity:0)},0)}
function renderCart(){
  const node=$('#cartItems');const filtered=state.cart.filter(i=>state.products.some(p=>p.id===i.id));
  if(filtered.length!==state.cart.length){state.cart=filtered;saveCart()}
  node.innerHTML=state.cart.length?state.cart.map(i=>{const p=state.products.find(p=>p.id===i.id);return `<div class="cart-item"><div class="cart-thumb" style="display:grid;place-items:center">${picture(p,'cart-thumb')}</div><div><h4>${escapeHtml(p.name)}</h4><p>${toman(p.price)}</p><div class="qty-control"><button data-qty="${p.id}" data-delta="1">+</button><span>${fa(i.quantity)}</span><button data-qty="${p.id}" data-delta="-1">−</button></div></div></div>`}).join(''):'<div class="cart-empty">سبد خریدت فعلاً خالیه ♡</div>';
  $('#cartTotal').textContent=toman(cartTotal());$('#checkoutBtn').disabled=!state.cart.length;
  node.querySelectorAll('[data-qty]').forEach(b=>b.addEventListener('click',()=>changeQty(Number(b.dataset.qty),Number(b.dataset.delta))));
}
function changeQty(id,delta){let item=state.cart.find(x=>x.id===id);if(!item)return;const p=state.products.find(x=>x.id===id);item.quantity=Math.min(p.stock,item.quantity+delta);if(item.quantity<1)state.cart=state.cart.filter(x=>x.id!==id);saveCart();renderCart()}
function addToCart(id){const p=state.products.find(x=>x.id===id);if(!p||p.stock<1)return toast('این محصول فعلاً موجود نیست');const item=state.cart.find(x=>x.id===id);if(item){if(item.quantity>=p.stock)return toast('موجودی بیشتری ثبت نشده');item.quantity++}else state.cart.push({id,quantity:1});saveCart();closeOverlay();toast('محصول به سبد خرید اضافه شد')}
function viewProduct(id){const p=state.products.find(x=>x.id===id);if(!p)return;
 $('#modalContent').innerHTML=`${p.images?.length?`<img class="modal-image" src="${escapeHtml(p.images[0])}" alt="${escapeHtml(p.name)}">`:`<div class="modal-image" style="display:grid;place-items:center;font:900 90px Arial;color:#ccc">AK.</div>`}<span class="label-sup">${escapeHtml(p.category)}</span><h2 id="modalTitle">${escapeHtml(p.name)}</h2><p>${escapeHtml(p.description||'')}</p><div class="totals"><b>${toman(p.price)}</b><span>${p.stock?`${fa(p.stock)} عدد موجود`:'ناموجود'}</span></div><button id="addProductBtn" class="btn btn-dark full" ${!p.stock?'disabled':''}>افزودن به سبد خرید +</button>`;
 $('#addProductBtn').addEventListener('click',()=>addToCart(id));openOverlay('modal')}
function formField(label,name,type='text',extra=''){return `<div class="field"><label for="f_${name}">${label}</label><input id="f_${name}" name="${name}" type="${type}" ${extra} required></div>`}
function authModal(mode='login'){
 const register=mode==='register';
 $('#modalContent').innerHTML=`<span class="label-sup">MY ARAK KALA</span><h2 id="modalTitle">${register?'ایجاد حساب کاربری':'ورود به حساب'}</h2><p>${register?'برای ثبت سفارش، حساب خودت را بساز.':'به فروشگاه خودت خوش اومدی.'}</p><form id="authForm">${register?formField('نام و نام خانوادگی','full_name'):''}${formField('ایمیل','email','email','autocomplete="email"')}${formField('رمز عبور (حداقل ۱۰ کاراکتر)','password','password','minlength="10" autocomplete="'+(register?'new-password':'current-password')+'"')}<button class="btn btn-dark full" type="submit">${register?'ثبت‌نام':'ورود'} ↖</button></form><p class="form-help">${register?'حساب داری؟':'هنوز حساب نداری؟'} <button class="text-button" id="switchAuth">${register?'وارد شو':'ثبت‌نام کن'}</button></p>`;
 $('#switchAuth').addEventListener('click',()=>authModal(register?'login':'register'));
 $('#authForm').addEventListener('submit',async e=>{e.preventDefault();const data=Object.fromEntries(new FormData(e.target));try{if(register){await api('/auth/register',{method:'POST',body:data});toast('ثبت‌نام انجام شد. وارد حساب شو.');authModal('login')}else{const r=await api('/auth/login',{method:'POST',body:data});if(r.user.role==='admin'){toast('حساب مدیر فقط از اپ مدیریت استفاده می‌کند');return;}state.token=r.token;state.user=r.user;sessionStorage.setItem('arak_token',r.token);closeOverlay();toast('خوش اومدی '+r.user.full_name)}}catch(err){toast(err.message)}});openOverlay('modal');
}
function accountModal(){if(!state.user)return authModal();$('#modalContent').innerHTML=`<span class="label-sup">MY ACCOUNT</span><h2 id="modalTitle">${escapeHtml(state.user.full_name)}</h2><p>${escapeHtml(state.user.email)}</p><button class="btn btn-dark full" id="accountOrders">سفارش‌های من</button><button class="text-button" id="logout" style="margin-top:16px">خروج از حساب</button>`;$('#accountOrders').onclick=ordersModal;$('#logout').onclick=async()=>{try{await api('/auth/logout',{method:'POST'})}catch{}state.token='';state.user=null;sessionStorage.removeItem('arak_token');closeOverlay();toast('از حساب خارج شدی')};openOverlay('modal')}
async function ordersModal(){if(!state.user)return authModal();try{const d=await api('/orders');$('#modalContent').innerHTML=`<span class="label-sup">YOUR ORDERS</span><h2 id="modalTitle">سفارش‌های من</h2>${d.orders.length?d.orders.map(o=>`<div class="order-row"><strong>سفارش #${fa(o.id)} · ${toman(o.total)}</strong><span>وضعیت: ${escapeHtml(o.status)} · ${new Date(o.created_at*1000).toLocaleDateString('fa-IR')}</span></div>`).join(''):'<p>هنوز سفارشی ثبت نکردی.</p>'}`;openOverlay('modal')}catch(e){toast(e.message)}}
function checkoutModal(){if(!state.cart.length)return;if(!state.user)return authModal();closeOverlay();$('#modalContent').innerHTML=`<span class="label-sup">CHECKOUT</span><h2 id="modalTitle">ثبت سفارش آزمایشی</h2><p>این نسخه هنوز پرداخت آنلاین و ارسال واقعی ندارد. سفارش صرفاً در سیستم ثبت می‌شود.</p><form id="checkoutForm">${formField('نام گیرنده','full_name','text','minlength="2"')}${formField('موبایل','phone','tel','minlength="8"')}<div class="field"><label for="address">نشانی کامل</label><textarea id="address" name="address" required minlength="8"></textarea></div><div class="totals"><span>مبلغ سفارش</span><b>${toman(cartTotal())}</b></div><button class="btn btn-dark full" type="submit">ثبت سفارش بدون پرداخت ↖</button></form>`;
 $('#f_full_name').value=state.user.full_name;
 $('#checkoutForm').addEventListener('submit',async e=>{e.preventDefault();const form=Object.fromEntries(new FormData(e.target));const items=state.cart.map(i=>({product_id:i.id,quantity:i.quantity}));try{const d=await api('/orders',{method:'POST',body:{...form,items}});state.cart=[];saveCart();await loadProducts();closeOverlay();toast(`سفارش آزمایشی شماره ${fa(d.order_id)} ثبت شد`)}catch(err){toast(err.message)}});openOverlay('modal')}
async function init(){loadCart();renderCartCount();await loadProducts();if(state.token){try{state.user=await api('/me');if(state.user.role!=='customer')throw new Error('not customer')}catch{state.token='';sessionStorage.removeItem('arak_token');state.user=null;}}}
$('#searchInput').addEventListener('input',e=>{state.search=e.target.value;renderProducts()});
['cartBtn','mobileCartBtn'].forEach(id=>$('#'+id).addEventListener('click',()=>{renderCart();openOverlay('drawer')}));
['accountBtn','mobileAccountBtn'].forEach(id=>$('#'+id).addEventListener('click',accountModal));
['ordersBtn','mobileOrdersBtn'].forEach(id=>$('#'+id).addEventListener('click',ordersModal));
$('#checkoutBtn').addEventListener('click',checkoutModal);
$('#overlay').addEventListener('click',closeOverlay);
document.querySelectorAll('[data-close]').forEach(x=>x.addEventListener('click',closeOverlay));
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeOverlay()});
init();
