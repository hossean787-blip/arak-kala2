#!/usr/bin/env python3
"""ARAK KALA single-store demonstration backend; Python 3.8+ / stdlib only.
Run with ARAK_ADMIN_PASSWORD env var to bootstrap the sole admin.
Use HTTPS, a real process manager and PostgreSQL before production deployment.
"""
import argparse
import base64
import binascii
import datetime
import hashlib
import hmac
import json
import mimetypes
import os
import re
import secrets
import sqlite3
import sys
import time
import urllib.parse
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from contextlib import closing
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WEB_DIR = ROOT / 'web'
DATA_DIR = Path(os.environ.get('ARAK_DATA_DIR', str(ROOT / 'backend' / 'data'))).resolve()
DB_PATH = DATA_DIR / 'store.sqlite3'
UPLOADS_DIR = DATA_DIR / 'uploads'
ADMIN_EMAIL = 'hossean787@gmail.com'
ALLOWED_STATUS = {'pending', 'processing', 'shipped', 'delivered', 'canceled'}
TRANSITIONS = {
    'pending': {'processing', 'canceled'},
    'processing': {'shipped', 'canceled'},
    'shipped': {'delivered'},
    'delivered': set(),
    'canceled': set(),
}

class ApiError(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status = status


def connect():
    db = sqlite3.connect(str(DB_PATH), timeout=10, isolation_level=None)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA foreign_keys=ON')
    db.execute('PRAGMA busy_timeout=10000')
    return db


def password_hash(password, salt=None):
    salt = salt or secrets.token_bytes(16)
    derived = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 240000)
    return salt.hex(), derived.hex()


def valid_password(raw):
    return isinstance(raw, str) and 10 <= len(raw) <= 128


def init_db():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    UPLOADS_DIR.mkdir(parents=True, exist_ok=True)
    with closing(connect()) as db:
        db.executescript('''
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT NOT NULL UNIQUE,
                full_name TEXT NOT NULL,
                phone TEXT NOT NULL DEFAULT '',
                role TEXT NOT NULL CHECK(role IN ('customer','admin')),
                salt TEXT NOT NULL,
                password_hash TEXT NOT NULL,
                created_at INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS sessions (
                token_hash TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                expires_at INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                description TEXT NOT NULL DEFAULT '',
                category TEXT NOT NULL DEFAULT 'سایر',
                price INTEGER NOT NULL CHECK(price >= 0),
                stock INTEGER NOT NULL CHECK(stock >= 0),
                image_urls TEXT NOT NULL DEFAULT '[]',
                active INTEGER NOT NULL DEFAULT 1,
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL REFERENCES users(id),
                full_name TEXT NOT NULL,
                phone TEXT NOT NULL,
                address TEXT NOT NULL,
                total INTEGER NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                created_at INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS order_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                order_id INTEGER NOT NULL REFERENCES orders(id),
                product_id INTEGER NOT NULL REFERENCES products(id),
                name TEXT NOT NULL,
                unit_price INTEGER NOT NULL,
                quantity INTEGER NOT NULL CHECK(quantity > 0)
            );
            CREATE INDEX IF NOT EXISTS idx_products_active ON products(active, category);
            CREATE INDEX IF NOT EXISTS idx_orders_user ON orders(user_id, created_at);
        ''')
        admin_password = os.environ.get('ARAK_ADMIN_PASSWORD', '')
        if admin_password:
            if not valid_password(admin_password):
                raise RuntimeError('ARAK_ADMIN_PASSWORD must have 10-128 characters')
            admin = db.execute('SELECT id FROM users WHERE email=?', (ADMIN_EMAIL,)).fetchone()
            if not admin:
                salt, pwh = password_hash(admin_password)
                db.execute('INSERT INTO users (email,full_name,role,salt,password_hash,created_at) VALUES (?,?,?,?,?,?)',
                           (ADMIN_EMAIL, 'مدیر اراک کالا', 'admin', salt, pwh, int(time.time())))
                print('Admin account initialized.', flush=True)
        # Never reset the admin password automatically after it is created.


def product_dict(p):
    return {'id': p['id'], 'name': p['name'], 'description': p['description'], 'category': p['category'],
            'price': p['price'], 'stock': p['stock'], 'images': json.loads(p['image_urls']),
            'active': bool(p['active'])}


def read_product_input(data, partial=False):
    if not isinstance(data, dict):
        raise ApiError(400, 'اطلاعات محصول معتبر نیست')
    result = {}
    for key, maximum in [('name', 140), ('description', 3000), ('category', 60)]:
        if key in data:
            if not isinstance(data[key], str) or len(data[key].strip()) > maximum:
                raise ApiError(400, 'مقدار فیلد ' + key + ' نامعتبر است')
            value = data[key].strip()
            if key == 'name' and not value:
                raise ApiError(400, 'نام محصول الزامی است')
            result[key] = value or ('سایر' if key == 'category' else '')
        elif not partial and key == 'name':
            raise ApiError(400, 'نام محصول الزامی است')
    for key in ('price', 'stock'):
        if key in data:
            v = data[key]
            if type(v) is not int or v < 0 or v > 1000000000000:
                raise ApiError(400, 'مقدار ' + key + ' نامعتبر است')
            result[key] = v
        elif not partial:
            raise ApiError(400, 'قیمت و موجودی الزامی هستند')
    if 'images' in data:
        images = data['images']
        if not isinstance(images, list) or len(images) > 8 or any(
            not isinstance(i, str) or not re.fullmatch(r'/uploads/[a-f0-9]{32}\.(jpg|png|webp)', i) for i in images
        ):
            raise ApiError(400, 'آدرس تصاویر نامعتبر است')
        result['image_urls'] = json.dumps(images, ensure_ascii=False)
    if 'active' in data:
        if type(data['active']) is not bool:
            raise ApiError(400, 'وضعیت فعال معتبر نیست')
        result['active'] = int(data['active'])
    return result


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(WEB_DIR), **kwargs)

    def log_message(self, fmt, *args):
        sys.stderr.write('%s - %s\n' % (self.address_string(), fmt % args))

    def headers_base(self):
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('Cache-Control', 'no-store')

    def reply(self, status, obj):
        body = json.dumps(obj, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.headers_base()
        self.end_headers()
        self.wfile.write(body)

    def read_json(self, max_bytes=150000):
        try:
            length = int(self.headers.get('Content-Length', '-1'))
        except ValueError:
            raise ApiError(400, 'طول درخواست نامعتبر است')
        if length < 0 or length > max_bytes:
            raise ApiError(413, 'حجم درخواست بیش از حد مجاز است')
        try:
            result = json.loads(self.rfile.read(length))
            if not isinstance(result, dict):
                raise ValueError('object required')
            return result
        except (ValueError, UnicodeDecodeError):
            raise ApiError(400, 'فرمت JSON نامعتبر است')

    def current_user(self, db, role=None):
        auth = self.headers.get('Authorization', '')
        if not auth.startswith('Bearer '):
            raise ApiError(401, 'ابتدا وارد حساب شوید')
        token = auth[7:]
        if len(token) > 150:
            raise ApiError(401, 'نشست نامعتبر است')
        token_hash = hashlib.sha256(token.encode()).hexdigest()
        user = db.execute('''SELECT u.id,u.email,u.full_name,u.role FROM sessions s JOIN users u ON s.user_id=u.id
                             WHERE s.token_hash=? AND s.expires_at>?''', (token_hash, int(time.time()))).fetchone()
        if not user:
            raise ApiError(401, 'نشست منقضی یا نامعتبر است')
        if role and user['role'] != role:
            raise ApiError(403, 'مجوز دسترسی ندارید')
        return user

    def run_api(self, method):
        parsed = urllib.parse.urlsplit(self.path)
        path = parsed.path
        params = urllib.parse.parse_qs(parsed.query)
        with closing(connect()) as db:
            if method == 'GET' and path == '/api/health':
                return self.reply(200, {'ok': True, 'service': 'arak-kala'})
            if method == 'POST' and path == '/api/auth/register':
                data = self.read_json()
                email = str(data.get('email', '')).strip().lower()
                full_name = str(data.get('full_name', '')).strip()
                phone = str(data.get('phone', '')).strip()
                password = data.get('password')
                if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+', email) or len(email) > 200 or not (2 <= len(full_name) <= 100) or not valid_password(password) or len(phone) > 25:
                    raise ApiError(400, 'نام، ایمیل یا رمز عبور معتبر نیست')
                if email == ADMIN_EMAIL:
                    raise ApiError(409, 'این ایمیل قابل ثبت‌نام نیست')
                salt, pwh = password_hash(password)
                try:
                    db.execute('INSERT INTO users (email,full_name,phone,role,salt,password_hash,created_at) VALUES (?,?,?,?,?,?,?)',
                               (email, full_name, phone, 'customer', salt, pwh, int(time.time())))
                except sqlite3.IntegrityError:
                    raise ApiError(409, 'این ایمیل قبلاً ثبت شده است')
                return self.reply(201, {'ok': True, 'message': 'حساب ایجاد شد'})
            if method == 'POST' and path == '/api/auth/login':
                data = self.read_json()
                email = str(data.get('email', '')).strip().lower()
                password = data.get('password')
                user = db.execute('SELECT * FROM users WHERE email=?', (email,)).fetchone()
                if not user or not isinstance(password, str):
                    raise ApiError(401, 'ایمیل یا رمز عبور صحیح نیست')
                try:
                    computed = bytes.fromhex(password_hash(password, bytes.fromhex(user['salt']))[1])
                    valid = hmac.compare_digest(computed, bytes.fromhex(user['password_hash']))
                except (ValueError, TypeError):
                    valid = False
                if not valid:
                    raise ApiError(401, 'ایمیل یا رمز عبور صحیح نیست')
                token = secrets.token_urlsafe(32)
                expires = int(time.time()) + 12 * 3600
                db.execute('INSERT INTO sessions(token_hash,user_id,expires_at) VALUES (?,?,?)',
                           (hashlib.sha256(token.encode()).hexdigest(), user['id'], expires))
                return self.reply(200, {'token': token, 'expires_at': expires,
                                        'user': {'id': user['id'], 'full_name': user['full_name'], 'role': user['role'], 'email': user['email']}})
            if method == 'POST' and path == '/api/auth/logout':
                user = self.current_user(db)
                token = self.headers['Authorization'][7:]
                db.execute('DELETE FROM sessions WHERE token_hash=? AND user_id=?',
                           (hashlib.sha256(token.encode()).hexdigest(), user['id']))
                return self.reply(200, {'ok': True})
            if method == 'GET' and path == '/api/me':
                u = self.current_user(db)
                return self.reply(200, {'id': u['id'], 'email': u['email'], 'full_name': u['full_name'], 'role': u['role']})
            if method == 'GET' and path == '/api/products':
                search = params.get('search', [''])[0][:140]
                category = params.get('category', [''])[0][:60]
                rows = db.execute('''SELECT * FROM products WHERE active=1 AND name LIKE ? AND category LIKE ? ORDER BY id DESC LIMIT 100''',
                                  ('%' + search + '%', category if category else '%')).fetchall()
                return self.reply(200, {'products': [product_dict(p) for p in rows]})
            if method == 'GET' and re.fullmatch(r'/api/products/\d+', path):
                pid = int(path.split('/')[-1])
                p = db.execute('SELECT * FROM products WHERE id=? AND active=1', (pid,)).fetchone()
                if not p:
                    raise ApiError(404, 'محصول پیدا نشد')
                return self.reply(200, product_dict(p))
            if path.startswith('/api/admin/'):
                self.current_user(db, role='admin')
                if method == 'GET' and path == '/api/admin/products':
                    rows = db.execute('SELECT * FROM products ORDER BY id DESC').fetchall()
                    return self.reply(200, {'products': [product_dict(p) for p in rows]})
                if method == 'POST' and path == '/api/admin/products':
                    data = read_product_input(self.read_json())
                    now = int(time.time())
                    cur = db.execute('INSERT INTO products(name,description,category,price,stock,image_urls,active,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)',
                                     (data['name'], data.get('description',''), data.get('category','سایر'), data['price'], data['stock'], data.get('image_urls','[]'), data.get('active',1), now, now))
                    return self.reply(201, {'id': cur.lastrowid, 'ok': True})
                if re.fullmatch(r'/api/admin/products/\d+', path):
                    pid = int(path.split('/')[-1])
                    exists = db.execute('SELECT 1 FROM products WHERE id=?', (pid,)).fetchone()
                    if not exists:
                        raise ApiError(404, 'محصول پیدا نشد')
                    if method == 'PATCH':
                        data = read_product_input(self.read_json(), partial=True)
                        if not data:
                            raise ApiError(400, 'هیچ فیلدی برای تغییر نیست')
                        data['updated_at'] = int(time.time())
                        cols = ','.join(k+'=?' for k in data)
                        db.execute('UPDATE products SET '+cols+' WHERE id=?', tuple(data.values())+(pid,))
                        return self.reply(200, {'ok': True})
                    if method == 'DELETE':
                        db.execute('UPDATE products SET active=0, updated_at=? WHERE id=?', (int(time.time()), pid))
                        return self.reply(200, {'ok': True})
                if method == 'POST' and path == '/api/admin/images':
                    data = self.read_json(max_bytes=4000000)
                    mime = data.get('mime')
                    if mime not in ('image/jpeg', 'image/png', 'image/webp'):
                        raise ApiError(400, 'فرمت تصویر پشتیبانی نمی‌شود')
                    try:
                        blob = base64.b64decode(data.get('base64',''), validate=True)
                    except (ValueError, binascii.Error):
                        raise ApiError(400, 'تصویر نامعتبر است')
                    if len(blob) == 0 or len(blob) > 2 * 1024 * 1024:
                        raise ApiError(413, 'تصویر باید حداکثر ۲ مگابایت باشد')
                    magic = {'image/png': blob.startswith(b'\x89PNG\r\n\x1a\n'),
                             'image/jpeg': blob.startswith(b'\xff\xd8\xff'),
                             'image/webp': blob.startswith(b'RIFF') and blob[8:12] == b'WEBP'}
                    if not magic[mime]:
                        raise ApiError(400, 'محتوای فایل با فرمت اعلام‌شده هماهنگ نیست')
                    extension = {'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp'}[mime]
                    name = secrets.token_hex(16) + '.' + extension
                    (UPLOADS_DIR / name).write_bytes(blob)
                    return self.reply(201, {'url': '/uploads/' + name})
                if method == 'GET' and path == '/api/admin/orders':
                    rows = db.execute('SELECT * FROM orders ORDER BY id DESC LIMIT 200').fetchall()
                    orders = [dict(o) for o in rows]
                    for o in orders:
                        o['items'] = [dict(i) for i in db.execute('SELECT product_id,name,unit_price,quantity FROM order_items WHERE order_id=?', (o['id'],)).fetchall()]
                    return self.reply(200, {'orders': orders})
                if method == 'GET' and path == '/api/admin/stats':
                    stats = {'products': db.execute('SELECT COUNT(*) FROM products WHERE active=1').fetchone()[0],
                             'orders': db.execute('SELECT COUNT(*) FROM orders').fetchone()[0],
                             'low_stock': db.execute('SELECT COUNT(*) FROM products WHERE active=1 AND stock < 5').fetchone()[0],
                             'sales_total': db.execute("SELECT COALESCE(SUM(total),0) FROM orders WHERE status IN ('processing','shipped','delivered')").fetchone()[0]}
                    return self.reply(200, stats)
                if method == 'PATCH' and re.fullmatch(r'/api/admin/orders/\d+/status', path):
                    oid = int(path.split('/')[4]); status = self.read_json().get('status')
                    if status not in ALLOWED_STATUS:
                        raise ApiError(400, 'وضعیت معتبر نیست')
                    db.execute('BEGIN IMMEDIATE')
                    order = db.execute('SELECT * FROM orders WHERE id=?', (oid,)).fetchone()
                    if not order:
                        raise ApiError(404, 'سفارش پیدا نشد')
                    if status not in TRANSITIONS[order['status']]:
                        raise ApiError(409, 'تغییر وضعیت سفارش مجاز نیست')
                    if status == 'canceled':
                        rows = db.execute('SELECT product_id,quantity FROM order_items WHERE order_id=?', (oid,)).fetchall()
                        for item in rows:
                            db.execute('UPDATE products SET stock=stock+? WHERE id=?', (item['quantity'],item['product_id']))
                    db.execute('UPDATE orders SET status=? WHERE id=?', (status, oid))
                    db.execute('COMMIT')
                    return self.reply(200, {'ok': True})
            if method == 'POST' and path == '/api/orders':
                user = self.current_user(db)
                data = self.read_json()
                items = data.get('items', [])
                full_name = str(data.get('full_name','')).strip()
                phone = str(data.get('phone','')).strip()
                address = str(data.get('address','')).strip()
                if not isinstance(items, list) or not 1 <= len(items) <= 30 or not 2 <= len(full_name) <= 100 or not 8 <= len(phone) <= 25 or not 8 <= len(address) <= 500:
                    raise ApiError(400, 'اطلاعات سفارش کامل نیست')
                merged = {}
                for item in items:
                    if not isinstance(item, dict) or type(item.get('product_id')) is not int or type(item.get('quantity')) is not int or not (1 <= item['quantity'] <= 100):
                        raise ApiError(400, 'اقلام سفارش نامعتبر هستند')
                    pid = item['product_id']
                    merged[pid] = merged.get(pid,0) + item['quantity']
                db.execute('BEGIN IMMEDIATE')
                total = 0; resolved = []
                for pid, qty in merged.items():
                    p = db.execute('SELECT id,name,price,stock,active FROM products WHERE id=?', (pid,)).fetchone()
                    if not p or not p['active'] or p['stock'] < qty:
                        raise ApiError(409, 'موجودی یکی از محصولات کافی نیست')
                    resolved.append((p,qty)); total += p['price'] * qty
                cur = db.execute('INSERT INTO orders(user_id,full_name,phone,address,total,status,created_at) VALUES (?,?,?,?,?,?,?)',
                                 (user['id'],full_name,phone,address,total,'pending',int(time.time())))
                oid=cur.lastrowid
                for p, qty in resolved:
                    changed = db.execute('UPDATE products SET stock=stock-? WHERE id=? AND stock>=?', (qty,p['id'],qty)).rowcount
                    if changed != 1:
                        raise ApiError(409, 'موجودی کافی نیست')
                    db.execute('INSERT INTO order_items(order_id,product_id,name,unit_price,quantity) VALUES (?,?,?,?,?)',
                               (oid,p['id'],p['name'],p['price'],qty))
                db.execute('COMMIT')
                return self.reply(201, {'order_id': oid, 'total': total, 'status': 'pending', 'payment_enabled': False})
            if method == 'GET' and path == '/api/orders':
                u = self.current_user(db)
                orders = [dict(o) for o in db.execute('SELECT * FROM orders WHERE user_id=? ORDER BY id DESC', (u['id'],)).fetchall()]
                for o in orders:
                    o['items'] = [dict(i) for i in db.execute('SELECT product_id,name,unit_price,quantity FROM order_items WHERE order_id=?', (o['id'],)).fetchall()]
                return self.reply(200, {'orders': orders})
        raise ApiError(404, 'مسیر پیدا نشد')

    def serve_api(self, method):
        try:
            return self.run_api(method)
        except ApiError as e:
            return self.reply(e.status, {'error': str(e)})
        except sqlite3.Error as e:
            print('Database error', repr(e), file=sys.stderr)
            return self.reply(500, {'error': 'خطای پایگاه داده'})
        except Exception as e:
            print('Unexpected server error', repr(e), file=sys.stderr)
            return self.reply(500, {'error': 'خطای داخلی سرور'})

    def do_GET(self):
        path = urllib.parse.urlsplit(self.path).path
        if path.startswith('/api/'):
            return self.serve_api('GET')
        if path.startswith('/uploads/'):
            name = path[len('/uploads/'):]
            if not re.fullmatch(r'[a-f0-9]{32}\.(jpg|png|webp)', name):
                return self.send_error(404)
            fpath = UPLOADS_DIR / name
            if not fpath.is_file():
                return self.send_error(404)
            content = fpath.read_bytes()
            self.send_response(200)
            self.send_header('Content-Type', mimetypes.guess_type(str(fpath))[0] or 'application/octet-stream')
            self.send_header('Content-Length', str(len(content)))
            self.send_header('X-Content-Type-Options','nosniff')
            self.end_headers()
            return self.wfile.write(content)
        if path == '/':
            self.path = '/index.html'
        return super().do_GET()

    def do_POST(self):
        return self.serve_api('POST')

    def do_PATCH(self):
        return self.serve_api('PATCH')

    def do_DELETE(self):
        return self.serve_api('DELETE')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--host', default='127.0.0.1')
    parser.add_argument('--port', type=int, default=8000)
    args = parser.parse_args()
    init_db()
    with ThreadingHTTPServer((args.host, args.port), Handler) as httpd:
        print('ARAK KALA demo on http://%s:%s' % httpd.server_address, flush=True)
        httpd.serve_forever()
