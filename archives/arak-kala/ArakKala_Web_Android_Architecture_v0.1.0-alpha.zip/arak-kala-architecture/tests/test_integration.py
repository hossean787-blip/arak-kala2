import base64
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError

ROOT=Path(__file__).resolve().parents[1]
ADMIN_PASS='test-admin-strong-password'
PNG=base64.b64encode(base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/l9cAAAAASUVORK5CYII=')).decode()

class Integration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory()
        sock=socket.socket();sock.bind(('127.0.0.1',0));cls.port=sock.getsockname()[1];sock.close()
        cls.base='http://127.0.0.1:%d'%cls.port
        env=dict(os.environ,ARAK_DATA_DIR=cls.temp.name,ARAK_ADMIN_PASSWORD=ADMIN_PASS)
        cls.proc=subprocess.Popen([sys.executable,str(ROOT/'backend/server.py'),'--port',str(cls.port)],env=env,
                                   stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        for _ in range(60):
            try:
                with urlopen(cls.base+'/api/health',timeout=.5):return
            except Exception:time.sleep(.1)
        raise RuntimeError('test server failed to start')

    @classmethod
    def tearDownClass(cls):
        cls.proc.terminate();cls.proc.wait(timeout=5);cls.temp.cleanup()

    def http(self, path, method='GET', body=None, token=None):
        headers={}
        if token:headers['Authorization']='Bearer '+token
        if body is not None:headers['Content-Type']='application/json'
        req=Request(self.base+path,data=json.dumps(body).encode() if body is not None else None,headers=headers,method=method)
        try:
            with urlopen(req,timeout=5) as res:
                text=res.read().decode()
                return res.status, json.loads(text) if path.startswith('/api/') else text
        except HTTPError as e:
            return e.code, json.loads(e.read().decode())

    def test_flow(self):
        status,raw=self.http('/api/products')
        self.assertEqual(status,200);self.assertEqual(raw['products'],[])
        status,_=self.http('/api/admin/products')
        self.assertEqual(status,401)
        status,_=self.http('/api/auth/register','POST',{'email':'hossean787@gmail.com','full_name':'Admin','password':'a password should never register'})
        self.assertEqual(status,409)
        status,_=self.http('/api/auth/register','POST',{'email':'one@example.com','full_name':'Test Customer','phone':'09120000000','password':'customer-super-secret'})
        self.assertEqual(status,201)
        status,_=self.http('/api/auth/register','POST',{'email':'one@example.com','full_name':'Test Customer','password':'customer-super-secret'})
        self.assertEqual(status,409)
        status,customer=self.http('/api/auth/login','POST',{'email':'one@example.com','password':'customer-super-secret'})
        self.assertEqual(status,200);self.assertEqual(customer['user']['role'],'customer');ct=customer['token']
        status,_=self.http('/api/admin/products',token=ct)
        self.assertEqual(status,403)
        status,admin=self.http('/api/auth/login','POST',{'email':'hossean787@gmail.com','password':ADMIN_PASS})
        self.assertEqual(status,200);self.assertEqual(admin['user']['role'],'admin');at=admin['token']
        status,_=self.http('/api/admin/images','POST',{'mime':'image/png','base64':'AAAA'},at)
        self.assertEqual(status,400)
        status,im=self.http('/api/admin/images','POST',{'mime':'image/png','base64':PNG},at)
        self.assertEqual(status,201)
        self.assertRegex(im['url'],r'^/uploads/[a-f0-9]{32}\.png$')
        with urlopen(self.base+im['url']) as resp:self.assertEqual(resp.status,200)
        status,prod=self.http('/api/admin/products','POST',{'name':'کتونی تست','description':'سایز ۴۰','category':'کفش','price':1200000,'stock':3,'images':[im['url']]},at)
        self.assertEqual(status,201);pid=prod['id']
        status,payload=self.http('/api/products?category=%DA%A9%D9%81%D8%B4')
        self.assertEqual(status,200);self.assertEqual(len(payload['products']),1)
        self.assertEqual(payload['products'][0]['images'],[im['url']])
        status,order=self.http('/api/orders','POST',{'full_name':'Test Customer','phone':'09120000000','address':'تهران، خیابان مثال، پلاک یک','items':[{'product_id':pid,'quantity':2,'price':1}]},ct)
        self.assertEqual(status,201);self.assertEqual(order['total'],2400000);self.assertFalse(order['payment_enabled'])
        status,p=self.http('/api/products/%d'%pid)
        self.assertEqual(p['stock'],1)
        status,missing=self.http('/api/orders','POST',{'full_name':'Test Customer','phone':'09120000000','address':'تهران، خیابان مثال، پلاک یک','items':[{'product_id':pid,'quantity':2}]},ct)
        self.assertEqual(status,409)
        status,user_orders=self.http('/api/orders',token=ct)
        self.assertEqual(len(user_orders['orders']),1)
        status,_=self.http('/api/admin/orders/%d/status'%order['order_id'],'PATCH',{'status':'canceled'},ct)
        self.assertEqual(status,403)
        status,_=self.http('/api/admin/orders/%d/status'%order['order_id'],'PATCH',{'status':'canceled'},at)
        self.assertEqual(status,200)
        status,p=self.http('/api/products/%d'%pid)
        self.assertEqual(p['stock'],3)
        status,_=self.http('/api/admin/orders/%d/status'%order['order_id'],'PATCH',{'status':'canceled'},at)
        self.assertEqual(status,409)
        status,_=self.http('/api/admin/products/%d'%pid,'PATCH',{'price':1400000,'stock':4},at)
        self.assertEqual(status,200)
        status,p=self.http('/api/products/%d'%pid)
        self.assertEqual(p['price'],1400000);self.assertEqual(p['stock'],4)
        status,_=self.http('/api/admin/products/%d'%pid,'DELETE',token=at)
        self.assertEqual(status,200)
        status,p=self.http('/api/products')
        self.assertEqual(p['products'],[])
        status,stat=self.http('/api/admin/stats',token=at)
        self.assertEqual(status,200);self.assertEqual(stat['products'],0)
        status,_=self.http('/api/auth/logout','POST',{},at)
        self.assertEqual(status,200)
        status,_=self.http('/api/admin/stats',token=at)
        self.assertEqual(status,401)

if __name__=='__main__':unittest.main()
