import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {mkdtemp,cp,rm} from 'node:fs/promises';
import os from 'node:os';import path from 'node:path';import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const tmp=await mkdtemp(path.join(os.tmpdir(),'arak-extra-'));
await cp(root,tmp,{recursive:true});
const port=20000+Math.floor(Math.random()*15000),token='testing-secret-only';
const server=spawn(process.execPath,['server.mjs'],{cwd:tmp,env:{...process.env,PORT:String(port),ADMIN_TOKEN:token}});
const req=async(p,method='GET',body,auth=false)=>{const r=await fetch(`http://127.0.0.1:${port}${p}`,{method,headers:{...(auth?{Authorization:`Bearer ${token}`} :{}),...(body?{'Content-Type':'application/json'}:{})},body:body?JSON.stringify(body):undefined});return {status:r.status,data:await r.json()}};
try{
let ready=false;for(let i=0;i<70;i++){try{await req('/api/health');ready=true;break}catch{await new Promise(r=>setTimeout(r,80))}}assert.ok(ready);
assert.equal((await req('/data/orders.json')).status,403);
assert.equal((await req('/tests/run-tests.mjs')).status,403);
assert.equal((await req('/api/admin/backup')).status,401);
const backup=await req('/api/admin/backup','GET',null,true);assert.equal(backup.status,200);assert.ok(Array.isArray(backup.data.products));
const first=backup.data.products.find(x=>x.stock>0);assert.ok(first);
const over=await req('/api/orders','POST',{customer:{name:'مشتری نمونه',phone:'09123456789',address:'نشانی نمونه و معتبر'},items:[{id:first.id,quantity:20}]});assert.equal(over.status,409);
const before=first.stock;
const good=await req('/api/orders','POST',{customer:{name:'مشتری نمونه',phone:'09123456789',address:'نشانی نمونه و معتبر'},items:[{id:first.id,quantity:1}]});assert.equal(good.status,201);
let after=await req('/api/admin/products','GET',null,true);assert.equal(after.data.find(x=>x.id===first.id).stock,before-1);
const cancel=await req('/api/admin/orders/'+good.data.id,'PATCH',{status:'cancelled'},true);assert.equal(cancel.status,200);
after=await req('/api/admin/products','GET',null,true);assert.equal(after.data.find(x=>x.id===first.id).stock,before);
console.log('PASS extra 7 checks: private files, backup access, stock guard, stock decrement, cancellation restore');
}finally{server.kill();await rm(tmp,{recursive:true,force:true})}
