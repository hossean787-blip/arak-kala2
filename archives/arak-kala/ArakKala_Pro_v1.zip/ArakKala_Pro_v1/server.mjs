import http from 'node:http';
import {readFile, writeFile, mkdir} from 'node:fs/promises';
import {existsSync} from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomUUID, timingSafeEqual} from 'node:crypto';
const ROOT=path.dirname(fileURLToPath(import.meta.url));
const DATA=path.join(ROOT,'data');
const PORT=Number(process.env.PORT||8000);
const HOST=process.env.HOST||'127.0.0.1';
let mutationQueue=Promise.resolve();
function exclusive(fn){const job=mutationQueue.then(fn);mutationQueue=job.catch(()=>{});return job;}
const ORDER_STATUSES=new Set(['pending_manual_review','confirmed','processing','shipped','completed','cancelled']);
const MAX_ORDERS=10000;
const SHIPPING_FEE=99000;
const FREE_SHIPPING_THRESHOLD=5000000;
const ORDER_RATE_LIMIT=8;
const RATE_WINDOW_MS=10*60*1000;
const orderAttempts=new Map();
const ADMIN_TOKEN=process.env.ADMIN_TOKEN||'';
const MIME={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.png':'image/png','.svg':'image/svg+xml','.ico':'image/x-icon'};
await mkdir(DATA,{recursive:true});
for(const [f,initial] of [['products.json',[]],['orders.json',[]]]) if(!existsSync(path.join(DATA,f))) await writeFile(path.join(DATA,f),JSON.stringify(initial,null,2));
const read=async f=>JSON.parse(await readFile(path.join(DATA,f),'utf8'));
const write=async(f,v)=>writeFile(path.join(DATA,f),JSON.stringify(v,null,2)+'\n');
const normalizePhone=value=>String(value||'').replace(/[\s-]/g,'').replace(/^\+98/,'0');
const send=(res,status,data)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(data));};
const safeEqual=(a,b)=>{const x=Buffer.from(String(a)),y=Buffer.from(String(b));return x.length===y.length&&timingSafeEqual(x,y)};
const authorized=req=>ADMIN_TOKEN && safeEqual((req.headers.authorization||'').replace(/^Bearer\s+/i,''),ADMIN_TOKEN);
async function body(req,limit=20000){let s='';for await(const chunk of req){s+=chunk;if(s.length>limit)throw Object.assign(new Error('درخواست بیش از حد بزرگ است'),{status:413});}try{return JSON.parse(s||'{}')}catch{throw Object.assign(new Error('JSON نامعتبر است'),{status:400})}}
function validProduct(p){return p&&typeof p.name==='string'&&p.name.trim().length>=2&&p.name.length<=120&&typeof p.category==='string'&&p.category.length<=50&&Number.isSafeInteger(p.price)&&p.price>=0&&p.price<=1_000_000_000_000&&typeof p.description==='string'&&p.description.length<=500;}
const server=http.createServer(async(req,res)=>{try{
 res.setHeader('Referrer-Policy','no-referrer');res.setHeader('X-Frame-Options','DENY');res.setHeader('Permissions-Policy','camera=(), microphone=(), geolocation=()');
 const url=new URL(req.url,'http://localhost'); const p=url.pathname;
 if(req.method==='GET'&&p==='/api/health')return send(res,200,{ok:true,service:'arak-kala',version:'0.3.0'});
 if(req.method==='GET'&&p==='/api/products'){const products=await read('products.json');return send(res,200,products.filter(x=>x.active!==false));}
 if(p.startsWith('/api/admin/')){
  if(!authorized(req))return send(res,401,{error:ADMIN_TOKEN?'توکن مدیر نامعتبر است':'مدیریت غیرفعال است؛ متغیر ADMIN_TOKEN را تنظیم کنید.'});
  if(req.method==='GET'&&p==='/api/admin/summary'){const [products,orders]=await Promise.all([read('products.json'),read('orders.json')]);return send(res,200,{products:products.length,activeProducts:products.filter(x=>x.active!==false).length,orders:orders.length,ordersPending:orders.filter(x=>x.status==='pending_manual_review').length,orderValue:orders.filter(x=>x.status!=='cancelled').reduce((a,x)=>a+x.total,0),lowStock:products.filter(x=>x.active!==false&&Number.isInteger(x.stock)&&x.stock<=5).map(x=>({id:x.id,name:x.name,stock:x.stock}))});}
  if(req.method==='GET'&&p==='/api/admin/backup'){const [products,orders]=await Promise.all([read('products.json'),read('orders.json')]);return send(res,200,{exportedAt:new Date().toISOString(),products,orders});}
  if(req.method==='GET'&&p==='/api/admin/orders'){const orders=await read('orders.json');return send(res,200,orders);}
  const orderMatch=p.match(/^\/api\/admin\/orders\/([^/]+)$/);
  if(orderMatch&&req.method==='PATCH')return exclusive(async()=>{const id=decodeURIComponent(orderMatch[1]);const patch=await body(req);if(!ORDER_STATUSES.has(patch.status))return send(res,400,{error:'وضعیت سفارش معتبر نیست.'});const orders=await read('orders.json');const order=orders.find(x=>x.id===id);if(!order)return send(res,404,{error:'سفارش پیدا نشد.'});if(order.status==='cancelled'&&patch.status!=='cancelled')return send(res,409,{error:'سفارش لغوشده قابل بازگشایی نیست.'});if(patch.status==='cancelled'&&order.status!=='cancelled'){const products=await read('products.json');for(const line of order.items){const product=products.find(x=>x.id===line.id);if(product&&Number.isInteger(product.stock))product.stock+=line.quantity;}await write('products.json',products);}order.status=patch.status;order.updatedAt=new Date().toISOString();await write('orders.json',orders);return send(res,200,{id:order.id,status:order.status});});
  if(req.method==='GET'&&p==='/api/admin/products')return send(res,200,await read('products.json'));
  if(req.method==='POST'&&p==='/api/admin/products')return exclusive(async()=>{const product=await body(req);if(!validProduct(product))return send(res,400,{error:'مشخصات محصول معتبر نیست.'});const products=await read('products.json');product.id=String(product.id||randomUUID());if(products.some(x=>x.id===product.id))return send(res,409,{error:'شناسه تکراری است.'});if(product.stock!==undefined&&(!Number.isSafeInteger(product.stock)||product.stock<0))return send(res,400,{error:'موجودی معتبر نیست.'});product.stock=product.stock??0;product.active=product.active!==false;products.push(product);await write('products.json',products);return send(res,201,product);});
  const match=p.match(/^\/api\/admin\/products\/([^/]+)$/);
  if(match&&req.method==='PATCH')return exclusive(async()=>{const id=decodeURIComponent(match[1]);const patch=await body(req);const products=await read('products.json');const i=products.findIndex(x=>x.id===id);if(i<0)return send(res,404,{error:'محصول پیدا نشد.'});const next={...products[i],...patch,id};if(next.stock!==undefined&&(!Number.isSafeInteger(next.stock)||next.stock<0))return send(res,400,{error:'موجودی معتبر نیست.'});if(!validProduct(next))return send(res,400,{error:'مشخصات محصول معتبر نیست.'});products[i]=next;await write('products.json',products);return send(res,200,next);});
  if(match&&req.method==='DELETE')return exclusive(async()=>{const id=decodeURIComponent(match[1]);const products=await read('products.json');const i=products.findIndex(x=>x.id===id);if(i<0)return send(res,404,{error:'محصول پیدا نشد.'});products[i].active=false;await write('products.json',products);return send(res,200,{ok:true,archived:id});});
  return send(res,404,{error:'مسیر مدیریت وجود ندارد.'});
 }
 if(req.method==='POST'&&p==='/api/orders')return exclusive(async()=>{
  const ip=String(req.socket.remoteAddress||'unknown');const now=Date.now();const attempts=(orderAttempts.get(ip)||[]).filter(t=>now-t<RATE_WINDOW_MS);if(attempts.length>=ORDER_RATE_LIMIT){orderAttempts.set(ip,attempts);res.setHeader('Retry-After',String(Math.ceil(RATE_WINDOW_MS/1000)));return send(res,429,{error:'تعداد تلاش‌های ثبت سفارش زیاد است؛ کمی بعد دوباره تلاش کنید.'});}attempts.push(now);orderAttempts.set(ip,attempts);if(orderAttempts.size>5000){for(const [key,times] of orderAttempts)if(!times.length||now-times[times.length-1]>RATE_WINDOW_MS)orderAttempts.delete(key);}
  const data=await body(req);if(!Array.isArray(data.items)||data.items.length<1||data.items.length>50)return send(res,400,{error:'سبد خرید معتبر نیست.'});
  const name=String(data.customer?.name||'').trim(),phone=String(data.customer?.phone||'').replace(/[\s-]/g,'');const address=String(data.customer?.address||'').trim();
  if(name.length<2||name.length>100||!/^(?:\+?98|0)?9\d{9}$/.test(phone)||address.length<8||address.length>500)return send(res,400,{error:'نام، شماره موبایل و نشانی معتبر لازم است.'});
  const products=await read('products.json');const lines=[];let subtotal=0;const quantities=new Map();
  for(const item of data.items){const product=products.find(x=>x.id===String(item.id)&&x.active!==false);const qty=Number(item.quantity);if(!product||!Number.isInteger(qty)||qty<1||qty>20)return send(res,400,{error:'یکی از محصولات یا تعداد آن معتبر نیست.'});quantities.set(product.id,(quantities.get(product.id)||0)+qty);if(Number.isInteger(product.stock)&&quantities.get(product.id)>product.stock)return send(res,409,{error:'موجودی کافی برای '+product.name+' وجود ندارد.'});subtotal+=product.price*qty;if(!Number.isSafeInteger(subtotal)||subtotal>10_000_000_000_000)return send(res,400,{error:'مبلغ سفارش از حد مجاز بیشتر است.'});lines.push({id:product.id,name:product.name,unitPrice:product.price,quantity:qty,lineTotal:product.price*qty});}
  const shipping=subtotal>=FREE_SHIPPING_THRESHOLD?0:SHIPPING_FEE;const total=subtotal+shipping;const orders=await read('orders.json');if(orders.length>=MAX_ORDERS)return send(res,503,{error:'ظرفیت ذخیره‌سازی نسخه آزمایشی پر شده است.'});const order={id:randomUUID(),createdAt:new Date().toISOString(),status:'pending_manual_review',customer:{name,phone,address},items:lines,subtotal,shipping,total,currency:'IRT',paymentStatus:'not_configured'};orders.unshift(order);for(const [id,qty] of quantities){const product=products.find(x=>x.id===id);if(Number.isInteger(product.stock))product.stock-=qty;}await write('orders.json',orders);await write('products.json',products);return send(res,201,{id:order.id,status:order.status,subtotal,shipping,total:order.total,message:'سفارش ثبت آزمایشی شد؛ پرداخت و ارسال خودکار فعال نیست.'});
 });
 if(p.startsWith('/api/'))return send(res,404,{error:'مسیر API پیدا نشد.'});
 if(p==='/data'||p.startsWith('/data/')||p==='/tests'||p.startsWith('/tests/')||p.startsWith('/.'))return send(res,403,{error:'دسترسی ممنوع است.'});
 let decoded;try{decoded=decodeURIComponent(p)}catch{return send(res,400,{error:'مسیر نامعتبر است.'})}if(decoded.split('/').some(segment=>segment.startsWith('.')&&segment.length>1))return send(res,403,{error:'دسترسی ممنوع است.'});let file=path.resolve(ROOT,'.'+(decoded==='/'?'/':decoded));if(decoded==='/')file=path.join(ROOT,'index.html');if(!file.startsWith(ROOT+path.sep)&&file!==ROOT)return send(res,403,{error:'ممنوع'});
 try{const data=await readFile(file);res.writeHead(200,{'Content-Type':MIME[path.extname(file)]||'application/octet-stream','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'self' https://fonts.googleapis.com https://fonts.gstatic.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; script-src 'self'; img-src 'self' data:; connect-src 'self'; base-uri 'self'; frame-ancestors 'none'"});res.end(data);}catch{return send(res,404,{error:'فایل پیدا نشد.'});}
 }catch(e){send(res,e.status||500,{error:e.status?e.message:'خطای داخلی سرور'});}});
server.listen(PORT,HOST,()=>console.log(`Arak Kala dev server: http://${HOST}:${PORT}`));
