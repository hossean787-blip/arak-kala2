import {mkdtemp, cp, rm, readFile, writeFile, mkdir} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {spawn} from 'node:child_process';
import assert from 'node:assert/strict';
import {setTimeout as delay} from 'node:timers/promises';
import {fileURLToPath} from 'node:url';
const root=path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const temp=await mkdtemp(path.join(tmpdir(),'arak-kala-test-'));
const port=19000+Math.floor(Math.random()*1000), token='test-only-token-very-long';
let child;
const results=[];
function check(name,fn){try{fn();results.push({name,ok:true})}catch(e){results.push({name,ok:false,error:e.message})}}
async function request(route,{method='GET',body,auth=true}={}){const headers={};if(body!==undefined)headers['Content-Type']='application/json';if(auth)headers.Authorization=`Bearer ${token}`;const res=await fetch(`http://127.0.0.1:${port}${route}`,{method,headers,body:body===undefined?undefined:JSON.stringify(body)});let data;try{data=await res.json()}catch{data=null}return {status:res.status,data};}
try{
 await cp(root,temp,{recursive:true,filter:(src)=>!src.includes(path.sep+'tests')&&!src.endsWith('.zip')});
 await mkdir(path.join(temp,'data'),{recursive:true});
 await writeFile(path.join(temp,'data','products.json'),await readFile(path.join(root,'products.json')));
 await writeFile(path.join(temp,'data','orders.json'),'[]\n');
 child=spawn(process.execPath,['server.mjs'],{cwd:temp,env:{...process.env,PORT:String(port),HOST:'127.0.0.1',ADMIN_TOKEN:token},stdio:'ignore'});
 let ready=false;for(let i=0;i<40;i++){try{if((await fetch(`http://127.0.0.1:${port}/api/health`)).ok){ready=true;break}}catch{}await delay(100)}
 assert(ready,'server did not start');
 let r=await request('/api/health',{auth:false});check('health endpoint',()=>assert.equal(r.status,200));
 r=await request('/api/products',{auth:false});check('public products endpoint',()=>{assert.equal(r.status,200);assert.ok(r.data.length>=1)});
 r=await request('/api/admin/products',{auth:false});check('admin rejects missing token',()=>assert.equal(r.status,401));
 r=await request('/api/admin/products',{auth:true});check('admin token accepted',()=>assert.equal(r.status,200));
 r=await request('/api/admin/products',{method:'POST',body:{name:'محصول آزمون',category:'آزمایشی',price:12345,description:'شرح آزمایش',emoji:'🧪',tag:'تست'}});const productId=r.data?.id;check('create product',()=>{assert.equal(r.status,201);assert.ok(productId)});
 r=await request(`/api/admin/products/${productId}`,{method:'PATCH',body:{name:'محصول ویرایش‌شده',category:'آزمایشی',price:54321,description:'شرح جدید'}});check('edit product',()=>{assert.equal(r.status,200);assert.equal(r.data.price,54321)});
 r=await request('/api/orders',{method:'POST',auth:false,body:{customer:{name:'مشتری آزمایشی',phone:'09123456789',address:'نشانی آزمایشی معتبر تهران'},items:[{id:productId,quantity:2}]}});const orderId=r.data?.id;check('create valid test order',()=>{assert.equal(r.status,201);assert.equal(r.data.total,108642)});
 r=await request('/api/orders',{method:'POST',auth:false,body:{customer:{name:'الف',phone:'abc',address:'x'},items:[{id:productId,quantity:1}]}});check('reject invalid order',()=>assert.equal(r.status,400));
 for(let i=0;i<6;i++) await request('/api/orders',{method:'POST',auth:false,body:{customer:{name:'الف',phone:'bad',address:'x'},items:[{id:productId,quantity:1}]}});
 r=await request('/api/orders',{method:'POST',auth:false,body:{customer:{name:'الف',phone:'bad',address:'x'},items:[{id:productId,quantity:1}]}});check('order endpoint rate limit',()=>assert.equal(r.status,429));
 r=await request(`/api/admin/orders/${orderId}`,{method:'PATCH',body:{status:'processing'}});check('update order status',()=>{assert.equal(r.status,200);assert.equal(r.data.status,'processing')});
 r=await request(`/api/admin/orders/${orderId}`,{method:'PATCH',body:{status:'invented'}});check('reject unknown order status',()=>assert.equal(r.status,400));
 r=await request(`/api/admin/products/${productId}`,{method:'DELETE'});check('archive product',()=>assert.equal(r.status,200));
 r=await request('/api/products',{auth:false});check('archived product hidden from storefront',()=>assert.ok(!r.data.some(x=>x.id===productId)));
 const bad=await fetch(`http://127.0.0.1:${port}/%E0%A4%A`);check('malformed path handled',()=>assert.equal(bad.status,400));
} catch(e){results.push({name:'test harness',ok:false,error:e.stack||e.message})}
finally{if(child){child.kill('SIGTERM');await delay(150)}await rm(temp,{recursive:true,force:true});}
for(const r of results)console.log(`${r.ok?'PASS':'FAIL'} ${r.name}${r.error?`: ${r.error}`:''}`);
console.log(`\n${results.filter(x=>x.ok).length}/${results.length} checks passed`);
if(results.some(x=>!x.ok))process.exitCode=1;
